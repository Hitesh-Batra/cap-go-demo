(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[712],{

/***/ 9618:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./AuthorLayout": 4856,
	"./AuthorLayout.js": 4856,
	"./ListLayout": 6055,
	"./ListLayout.js": 6055,
	"./PostLayout": 5067,
	"./PostLayout.js": 5067,
	"./PostSimple": 3168,
	"./PostSimple.js": 3168
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 9618;

/***/ }),

/***/ 8100:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _extends() {
    _extends = Object.assign || function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}


// eslint-disable-next-line jsx-a11y/alt-text
var Image = function(_param) /*#__PURE__*/ {
    var rest = _extends({}, _param);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], _objectSpread({}, rest));
};
/* harmony default export */ __webpack_exports__["Z"] = (Image);


/***/ }),

/***/ 1712:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "J": function() { return /* binding */ MDXLayoutRenderer; }
});

// UNUSED EXPORTS: MDXComponents

// EXTERNAL MODULE: ./node_modules/preact/compat/jsx-runtime.mjs
var jsx_runtime = __webpack_require__(7320);
// EXTERNAL MODULE: ./node_modules/preact/compat/dist/compat.module.js + 1 modules
var compat_module = __webpack_require__(1720);
// EXTERNAL MODULE: ./node_modules/mdx-bundler/client/index.js
var client = __webpack_require__(3194);
// EXTERNAL MODULE: ./components/Image.js
var Image = __webpack_require__(8100);
// EXTERNAL MODULE: ./components/Link.js
var Link = __webpack_require__(7233);
;// CONCATENATED MODULE: ./components/TOCInline.js

/**
 * @typedef TocHeading
 * @prop {string} value
 * @prop {number} depth
 * @prop {string} url
 */ /**
 * Generates an inline table of contents
 * Exclude titles matching this string (new RegExp('^(' + string + ')$', 'i')).
 * If an array is passed the array gets joined with a pipe (new RegExp('^(' + array.join('|') + ')$', 'i')).
 *
 * @param {{
 *  toc: TocHeading[],
 *  indentDepth?: number,
 *  fromHeading?: number,
 *  toHeading?: number,
 *  asDisclosure?: boolean,
 *  exclude?: string|string[]
 * }} props
 *
 */ var TOCInline = function(param) {
    var toc = param.toc, _indentDepth = param.indentDepth, indentDepth = _indentDepth === void 0 ? 3 : _indentDepth, _fromHeading = param.fromHeading, fromHeading = _fromHeading === void 0 ? 1 : _fromHeading, _toHeading = param.toHeading, toHeading = _toHeading === void 0 ? 6 : _toHeading, _asDisclosure = param.asDisclosure, asDisclosure = _asDisclosure === void 0 ? false : _asDisclosure, _exclude = param.exclude, exclude = _exclude === void 0 ? "" : _exclude;
    var re = Array.isArray(exclude) ? new RegExp("^(" + exclude.join("|") + ")$", "i") : new RegExp("^(" + exclude + ")$", "i");
    var filteredToc = toc.filter(function(heading) {
        return heading.depth >= fromHeading && heading.depth <= toHeading && !re.test(heading.value);
    });
    var tocList = /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("ul", {
        children: filteredToc.map(function(heading) {
            return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("li", {
                className: "".concat(heading.depth >= indentDepth && "ml-6"),
                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("a", {
                    href: heading.url,
                    children: heading.value
                })
            }, heading.value);
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(jsx_runtime/* Fragment */.HY, {
        children: asDisclosure ? /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("details", {
            open: true,
            children: [
                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("summary", {
                    className: "ml-6 pt-2 pb-2 text-xl font-bold",
                    children: "Table of Contents"
                }),
                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                    className: "ml-6",
                    children: tocList
                })
            ]
        }) : tocList
    });
};
/* harmony default export */ var components_TOCInline = (TOCInline);

;// CONCATENATED MODULE: ./components/Pre.js


var Pre = function(props) {
    var textInput = (0,compat_module.useRef)(null);
    var ref = (0,compat_module.useState)(false), hovered = ref[0], setHovered = ref[1];
    var ref1 = (0,compat_module.useState)(false), copied = ref1[0], setCopied = ref1[1];
    var onEnter = function() {
        setHovered(true);
    };
    var onExit = function() {
        setHovered(false);
        setCopied(false);
    };
    var onCopy = function() {
        setCopied(true);
        navigator.clipboard.writeText(textInput.current.textContent);
        setTimeout(function() {
            setCopied(false);
        }, 2000);
    };
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
        ref: textInput,
        onMouseEnter: onEnter,
        onMouseLeave: onExit,
        className: "relative",
        children: [
            hovered && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                "aria-label": "Copy code",
                type: "button",
                className: "absolute right-2 top-2 h-8 w-8 rounded border-2 bg-gray-700 p-1 dark:bg-gray-800 ".concat(copied ? "border-green-400 focus:border-green-400 focus:outline-none" : "border-gray-300"),
                onClick: onCopy,
                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    fill: "none",
                    className: copied ? "text-green-400" : "text-gray-300",
                    children: copied ? /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(jsx_runtime/* Fragment */.HY, {
                        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"
                        })
                    }) : /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(jsx_runtime/* Fragment */.HY, {
                        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("pre", {
                children: props.children
            })
        ]
    });
};
/* harmony default export */ var components_Pre = (Pre);

// EXTERNAL MODULE: ./components/NewsletterForm.js
var NewsletterForm = __webpack_require__(7726);
;// CONCATENATED MODULE: ./components/MDXComponents.js
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}

/* eslint-disable react/display-name */ 






var MDXComponents = {
    Image: Image/* default */.Z,
    TOCInline: components_TOCInline,
    a: Link/* default */.Z,
    pre: components_Pre,
    BlogNewsletterForm: NewsletterForm/* BlogNewsletterForm */.w,
    wrapper: function(_param) {
        var components = _param.components, layout = _param.layout, rest = _objectWithoutProperties(_param, [
            "components",
            "layout"
        ]);
        var Layout = __webpack_require__(9618)("./".concat(layout)).default;
        return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Layout, _objectSpread({}, rest));
    }
};

var MDXLayoutRenderer = function(_param) {
    var layout = _param.layout, mdxSource = _param.mdxSource, rest = _objectWithoutProperties(_param, [
        "layout",
        "mdxSource"
    ]);
    var MDXLayout = (0,compat_module.useMemo)(function() {
        return (0,client.getMDXComponent)(mdxSource);
    }, [
        mdxSource
    ]);
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(MDXLayout, _objectSpread({
        layout: layout,
        components: MDXComponents
    }, rest));
};



/***/ }),

/***/ 7726:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": function() { return /* binding */ BlogNewsletterForm; }
/* harmony export */ });
/* harmony import */ var _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4051);
/* harmony import */ var _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7320);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1720);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}




var NewsletterForm = function(param) {
    var _title = param.title, title = _title === void 0 ? "Subscribe to the newsletter" : _title;
    var inputEl = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    var ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false), error1 = ref[0], setError = ref[1];
    var ref1 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""), message = ref1[0], setMessage = ref1[1];
    var ref2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false), subscribed = ref2[0], setSubscribed = ref2[1];
    var subscribe = function() {
        var _ref = _asyncToGenerator(_Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().mark(function _callee(e) {
            var res, error;
            return _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().wrap(function _callee$(_ctx) {
                while(1)switch(_ctx.prev = _ctx.next){
                    case 0:
                        e.preventDefault();
                        _ctx.next = 3;
                        return fetch("/api/".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().newsletter.provider)), {
                            body: JSON.stringify({
                                email: inputEl.current.value
                            }),
                            headers: {
                                "Content-Type": "application/json"
                            },
                            method: "POST"
                        });
                    case 3:
                        res = _ctx.sent;
                        _ctx.next = 6;
                        return res.json();
                    case 6:
                        error = _ctx.sent.error;
                        if (!error) {
                            _ctx.next = 11;
                            break;
                        }
                        setError(true);
                        setMessage("Your e-mail address is invalid or you are already subscribed!");
                        return _ctx.abrupt("return");
                    case 11:
                        inputEl.current.value = "";
                        setError(false);
                        setSubscribed(true);
                        setMessage("Successfully! \uD83C\uDF89 You are now subscribed.");
                    case 15:
                    case "end":
                        return _ctx.stop();
                }
            }, _callee);
        }));
        return function subscribe(e) {
            return _ref.apply(this, arguments);
        };
    }();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                className: "pb-1 text-lg font-semibold text-gray-800 dark:text-gray-100",
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("form", {
                className: "flex flex-col sm:flex-row",
                onSubmit: subscribe,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("label", {
                                className: "sr-only",
                                htmlFor: "email-input",
                                children: "Email address"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("input", {
                                autoComplete: "email",
                                className: "w-72 rounded-md px-4 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-primary-600 dark:bg-black",
                                id: "email-input",
                                name: "email",
                                placeholder: subscribed ? "You're subscribed !  \uD83C\uDF89" : "Enter your email",
                                ref: inputEl,
                                required: true,
                                type: "email",
                                disabled: subscribed
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                        className: "mt-2 flex w-full rounded-md shadow-sm sm:mt-0 sm:ml-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("button", {
                            className: "w-full rounded-md bg-primary-500 py-2 px-4 font-medium text-white sm:py-0 ".concat(subscribed ? "cursor-default" : "hover:bg-primary-700 dark:hover:bg-primary-400", " focus:outline-none focus:ring-2 focus:ring-primary-600 focus:ring-offset-2 dark:ring-offset-black"),
                            type: "submit",
                            disabled: subscribed,
                            children: subscribed ? "Thank you!" : "Sign up"
                        })
                    })
                ]
            }),
            error1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                className: "w-72 pt-2 text-sm text-red-500 dark:text-red-400 sm:w-96",
                children: message
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["Z"] = (NewsletterForm);
var BlogNewsletterForm = function(param) {
    var title = param.title;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
        className: "flex items-center justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
            className: "bg-gray-100 p-6 dark:bg-gray-800 sm:px-14 sm:py-8",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(NewsletterForm, {
                title: title
            })
        })
    });
};


/***/ }),

/***/ 920:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ PageTitle; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);

function PageTitle(param) {
    var children = param.children;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("h1", {
        className: "text-3xl font-extrabold leading-9 tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl sm:leading-10 md:text-5xl md:leading-14",
        children: children
    });
};


/***/ }),

/***/ 9831:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TQ": function() { return /* binding */ PageSEO; },
/* harmony export */   "$t": function() { return /* binding */ TagSEO; },
/* harmony export */   "Uy": function() { return /* binding */ BlogSEO; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9008);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1163);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);




var CommonSEO = function(param1) {
    var title = param1.title, description = param1.description, ogType = param1.ogType, ogImage = param1.ogImage, twImage = param1.twImage, canonicalUrl = param1.canonicalUrl;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("title", {
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "robots",
                content: "follow, index"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:url",
                content: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:type",
                content: ogType
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:site_name",
                content: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().title)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:title",
                content: title
            }),
            ogImage.constructor.name === "Array" ? ogImage.map(function(param) {
                var url = param.url;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                    property: "og:image",
                    content: url
                }, url);
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:image",
                content: ogImage
            }, ogImage),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:site",
                content: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().twitter)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:title",
                content: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:image",
                content: twImage
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("link", {
                rel: "canonical",
                href: canonicalUrl ? canonicalUrl : "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath)
            })
        ]
    });
};
var PageSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var twImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
        title: title,
        description: description,
        ogType: "website",
        ogImage: ogImageUrl,
        twImage: twImageUrl
    });
};
var TagSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var twImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
                title: title,
                description: description,
                ogType: "website",
                ogImage: ogImageUrl,
                twImage: twImageUrl
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("link", {
                    rel: "alternate",
                    type: "application/rss+xml",
                    title: "".concat(description, " - RSS feed"),
                    href: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath, "/feed.xml")
                })
            })
        ]
    });
};
var BlogSEO = function(param) {
    var authorDetails = param.authorDetails, title = param.title, summary = param.summary, date = param.date, lastmod = param.lastmod, url = param.url, _images = param.images, images = _images === void 0 ? [] : _images, canonicalUrl = param.canonicalUrl;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    var publishedAt = new Date(date).toISOString();
    var modifiedAt = new Date(lastmod || date).toISOString();
    var imagesArr = images.length === 0 ? [
        (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner)
    ] : typeof images === "string" ? [
        images
    ] : images;
    var featuredImages = imagesArr.map(function(img) {
        return {
            "@type": "ImageObject",
            url: img.includes("http") ? img : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + img
        };
    });
    var authorList;
    if (authorDetails) {
        authorList = authorDetails.map(function(author) {
            return {
                "@type": "Person",
                name: author.name
            };
        });
    } else {
        authorList = {
            "@type": "Person",
            name: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().author)
        };
    }
    var structuredData = {
        "@context": "https://schema.org",
        "@type": "Article",
        mainEntityOfPage: {
            "@type": "WebPage",
            "@id": url
        },
        headline: title,
        image: featuredImages,
        datePublished: publishedAt,
        dateModified: modifiedAt,
        author: authorList,
        publisher: {
            "@type": "Organization",
            name: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().author),
            logo: {
                "@type": "ImageObject",
                url: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteLogo))
            }
        },
        description: summary
    };
    var twImageUrl = featuredImages[0].url;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
                title: title,
                description: summary,
                ogType: "article",
                ogImage: featuredImages,
                twImage: twImageUrl,
                canonicalUrl: canonicalUrl
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: [
                    date && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                        property: "article:published_time",
                        content: publishedAt
                    }),
                    lastmod && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                        property: "article:modified_time",
                        content: modifiedAt
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(structuredData, null, 2)
                        }
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 7175:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1720);



var ScrollTopAndComment = function() {
    var ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false), show = ref[0], setShow = ref[1];
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function() {
        var handleWindowScroll = function() {
            if (window.scrollY > 50) setShow(true);
            else setShow(false);
        };
        window.addEventListener("scroll", handleWindowScroll);
        return function() {
            return window.removeEventListener("scroll", handleWindowScroll);
        };
    }, []);
    var handleScrollTop = function() {
        window.scrollTo({
            top: 0
        });
    };
    var handleScrollToComment = function() {
        document.getElementById("comment").scrollIntoView();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
        className: "fixed right-8 bottom-8 hidden flex-col gap-3 ".concat(show ? "md:flex" : "md:hidden"),
        children: [
            (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment.provider) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("button", {
                "aria-label": "Scroll To Comment",
                type: "button",
                onClick: handleScrollToComment,
                className: "rounded-full bg-gray-200 p-2 text-gray-500 transition-all hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-400 dark:hover:bg-gray-600",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("svg", {
                    className: "h-5 w-5",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("path", {
                        fillRule: "evenodd",
                        d: "M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z",
                        clipRule: "evenodd"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("button", {
                "aria-label": "Scroll To Top",
                type: "button",
                onClick: handleScrollTop,
                className: "rounded-full bg-gray-200 p-2 text-gray-500 transition-all hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-400 dark:hover:bg-gray-600",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("svg", {
                    className: "h-5 w-5",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("path", {
                        fillRule: "evenodd",
                        d: "M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z",
                        clipRule: "evenodd"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["Z"] = (ScrollTopAndComment);


/***/ }),

/***/ 9019:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _lib_utils_kebabCase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4871);



var Tag = function(param) {
    var text = param.text;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
        href: "/tags/".concat((0,_lib_utils_kebabCase__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(text)),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("a", {
            className: "mr-3 text-sm font-medium uppercase text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
            children: text.split(" ").join("-")
        })
    });
};
/* harmony default export */ __webpack_exports__["Z"] = (Tag);


/***/ }),

/***/ 896:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);



var UtterancesComponent = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_2__["default"])(function() {
    return __webpack_require__.e(/* import() */ 806).then(__webpack_require__.bind(__webpack_require__, 8806));
}, {
    loadableGenerated: {
        webpack: function() {
            return [
                /*require.resolve*/(8806)
            ];
        }
    },
    ssr: false
});
var GiscusComponent = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_2__["default"])(function() {
    return __webpack_require__.e(/* import() */ 732).then(__webpack_require__.bind(__webpack_require__, 732));
}, {
    loadableGenerated: {
        webpack: function() {
            return [
                /*require.resolve*/(732)
            ];
        }
    },
    ssr: false
});
var DisqusComponent = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_2__["default"])(function() {
    return __webpack_require__.e(/* import() */ 257).then(__webpack_require__.bind(__webpack_require__, 257));
}, {
    loadableGenerated: {
        webpack: function() {
            return [
                /*require.resolve*/(257)
            ];
        }
    },
    ssr: false
});
var Comments = function(param) {
    var frontMatter = param.frontMatter;
    var comment = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default()) === null || (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default()) === void 0 ? void 0 : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment);
    if (!comment || Object.keys(comment).length === 0) return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
        id: "comment",
        children: [
            (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment) && (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment.provider) === "giscus" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(GiscusComponent, {}),
            (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment) && (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment.provider) === "utterances" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(UtterancesComponent, {}),
            (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment) && (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_1___default().comment.provider) === "disqus" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(DisqusComponent, {
                frontMatter: frontMatter
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["Z"] = (Comments);


/***/ }),

/***/ 4856:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ AuthorLayout; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _components_social_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2557);
/* harmony import */ var _components_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8100);
/* harmony import */ var _components_SEO__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9831);




function AuthorLayout(param) {
    var children = param.children, frontMatter = param.frontMatter;
    var name = frontMatter.name, avatar = frontMatter.avatar, occupation = frontMatter.occupation, company = frontMatter.company, email = frontMatter.email, twitter = frontMatter.twitter, linkedin = frontMatter.linkedin, github = frontMatter.github;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_SEO__WEBPACK_IMPORTED_MODULE_3__/* .PageSEO */ .TQ, {
                title: "About - ".concat(name),
                description: "About me - ".concat(name)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                className: "divide-y divide-gray-200 dark:divide-gray-700",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                        className: "space-y-2 pt-6 pb-8 md:space-y-5",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("h1", {
                            className: "text-3xl font-extrabold leading-9 tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl sm:leading-10 md:text-6xl md:leading-14",
                            children: "About"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                        className: "items-start space-y-2 xl:grid xl:grid-cols-3 xl:gap-x-8 xl:space-y-0",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                className: "flex flex-col items-center pt-8",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        src: avatar,
                                        alt: "avatar",
                                        width: "192px",
                                        height: "192px",
                                        className: "h-48 w-48 rounded-full"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("h3", {
                                        className: "pt-4 pb-2 text-2xl font-bold leading-8 tracking-tight",
                                        children: name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                        className: "text-gray-500 dark:text-gray-400",
                                        children: occupation
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                        className: "text-gray-500 dark:text-gray-400",
                                        children: company
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                        className: "flex space-x-3 pt-6",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_social_icons__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                kind: "mail",
                                                href: "mailto:".concat(email)
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_social_icons__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                kind: "github",
                                                href: github
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_social_icons__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                kind: "linkedin",
                                                href: linkedin
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_social_icons__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                kind: "twitter",
                                                href: twitter
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                className: "prose max-w-none pt-8 pb-8 dark:prose-dark xl:col-span-2",
                                children: children
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 6055:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ ListLayout; }
});

// EXTERNAL MODULE: ./node_modules/preact/compat/jsx-runtime.mjs
var jsx_runtime = __webpack_require__(7320);
// EXTERNAL MODULE: ./components/Link.js
var Link = __webpack_require__(7233);
// EXTERNAL MODULE: ./components/Tag.js
var Tag = __webpack_require__(9019);
// EXTERNAL MODULE: ./data/siteMetadata.js
var siteMetadata = __webpack_require__(1576);
// EXTERNAL MODULE: ./node_modules/preact/compat/dist/compat.module.js + 1 modules
var compat_module = __webpack_require__(1720);
;// CONCATENATED MODULE: ./components/Pagination.js


function Pagination(param) {
    var totalPages = param.totalPages, currentPage = param.currentPage;
    var prevPage = parseInt(currentPage) - 1 > 0;
    var nextPage = parseInt(currentPage) + 1 <= parseInt(totalPages);
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
        className: "space-y-2 pt-6 pb-8 md:space-y-5",
        children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("nav", {
            className: "flex justify-between",
            children: [
                !prevPage && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                    rel: "previous",
                    className: "cursor-auto disabled:opacity-50",
                    disabled: !prevPage,
                    children: "Previous"
                }),
                prevPage && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                    href: currentPage - 1 === 1 ? "/blog/" : "/blog/page/".concat(currentPage - 1),
                    children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                        rel: "previous",
                        children: "Previous"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("span", {
                    children: [
                        currentPage,
                        " of ",
                        totalPages
                    ]
                }),
                !nextPage && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                    rel: "next",
                    className: "cursor-auto disabled:opacity-50",
                    disabled: !nextPage,
                    children: "Next"
                }),
                nextPage && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                    href: "/blog/page/".concat(currentPage + 1),
                    children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                        rel: "next",
                        children: "Next"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./lib/utils/formatDate.js
var formatDate = __webpack_require__(6232);
;// CONCATENATED MODULE: ./layouts/ListLayout.js







function ListLayout(param) {
    var posts = param.posts, title1 = param.title, _initialDisplayPosts = param.initialDisplayPosts, initialDisplayPosts = _initialDisplayPosts === void 0 ? [] : _initialDisplayPosts, pagination = param.pagination;
    var ref = (0,compat_module.useState)(""), searchValue = ref[0], setSearchValue = ref[1];
    var filteredBlogPosts = posts.filter(function(frontMatter) {
        var searchContent = frontMatter.title + frontMatter.summary + frontMatter.tags.join(" ");
        return searchContent.toLowerCase().includes(searchValue.toLowerCase());
    });
    // If initialDisplayPosts exist, display it if no searchValue is specified
    var displayPosts = initialDisplayPosts.length > 0 && !searchValue ? initialDisplayPosts : filteredBlogPosts;
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                className: "divide-y divide-gray-200 dark:divide-gray-700",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                        className: "space-y-2 pt-6 pb-8 md:space-y-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("h1", {
                                className: "text-3xl font-extrabold leading-9 tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl sm:leading-10 md:text-6xl md:leading-14",
                                children: title1
                            }),
                            /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                                className: "relative max-w-lg",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("input", {
                                        "aria-label": "Search articles",
                                        type: "text",
                                        onChange: function(e) {
                                            return setSearchValue(e.target.value);
                                        },
                                        placeholder: "Search articles",
                                        className: "block w-full rounded-md border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-900 dark:bg-gray-800 dark:text-gray-100"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("svg", {
                                        className: "absolute right-3 top-3 h-5 w-5 text-gray-400 dark:text-gray-300",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("ul", {
                        children: [
                            !filteredBlogPosts.length && "No posts found.",
                            displayPosts.map(function(frontMatter) {
                                var slug = frontMatter.slug, date = frontMatter.date, title = frontMatter.title, summary = frontMatter.summary, tags = frontMatter.tags;
                                return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("li", {
                                    className: "py-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("article", {
                                        className: "space-y-2 xl:grid xl:grid-cols-4 xl:items-baseline xl:space-y-0",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("dl", {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("dt", {
                                                        className: "sr-only",
                                                        children: "Published on"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("dd", {
                                                        className: "text-base font-medium leading-6 text-gray-500 dark:text-gray-400",
                                                        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("time", {
                                                            dateTime: date,
                                                            children: (0,formatDate/* default */.Z)(date)
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                                                className: "space-y-3 xl:col-span-3",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("h3", {
                                                                className: "text-2xl font-bold leading-8 tracking-tight",
                                                                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                                                                    href: "/blog/".concat(slug),
                                                                    className: "text-gray-900 dark:text-gray-100",
                                                                    children: title
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                                                                className: "flex flex-wrap",
                                                                children: tags.map(function(tag) {
                                                                    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Tag/* default */.Z, {
                                                                        text: tag
                                                                    }, tag);
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                                                        className: "prose max-w-none text-gray-500 dark:text-gray-400",
                                                        children: summary
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, slug);
                            })
                        ]
                    })
                ]
            }),
            pagination && pagination.totalPages > 1 && !searchValue && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Pagination, {
                currentPage: pagination.currentPage,
                totalPages: pagination.totalPages
            })
        ]
    });
};


/***/ }),

/***/ 5067:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ PostLayout; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _components_Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7233);
/* harmony import */ var _components_PageTitle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(920);
/* harmony import */ var _components_SectionContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(890);
/* harmony import */ var _components_SEO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9831);
/* harmony import */ var _components_Image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8100);
/* harmony import */ var _components_Tag__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9019);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_comments__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(896);
/* harmony import */ var _components_ScrollTopAndComment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7175);
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}










var editUrl = function(fileName) {
    return "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_7___default().siteRepo), "/blob/master/data/blog/").concat(fileName);
};
var discussUrl = function(slug) {
    return "https://mobile.twitter.com/search?q=".concat(encodeURIComponent("".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_7___default().siteUrl), "/blog/").concat(slug)));
};
var postDateTemplate = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
};
function PostLayout(param) {
    var frontMatter = param.frontMatter, authorDetails = param.authorDetails, next = param.next, prev = param.prev, children = param.children;
    var slug = frontMatter.slug, fileName = frontMatter.fileName, date = frontMatter.date, title = frontMatter.title, images = frontMatter.images, tags = frontMatter.tags;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(_components_SectionContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_SEO__WEBPACK_IMPORTED_MODULE_4__/* .BlogSEO */ .Uy, _objectSpread({
                url: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_7___default().siteUrl), "/blog/").concat(slug),
                authorDetails: authorDetails
            }, frontMatter)),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_ScrollTopAndComment__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("article", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                    className: "xl:divide-y xl:divide-gray-200 xl:dark:divide-gray-700",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("header", {
                            className: "pt-6 xl:pb-6",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                className: "space-y-1 text-center",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dl", {
                                        className: "space-y-10",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dt", {
                                                    className: "sr-only",
                                                    children: "Published on"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dd", {
                                                    className: "text-base font-medium leading-6 text-gray-500 dark:text-gray-400",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("time", {
                                                        dateTime: date,
                                                        children: new Date(date).toLocaleDateString((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_7___default().locale), postDateTemplate)
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_PageTitle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            children: title
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                            className: "divide-y divide-gray-200 pb-8 dark:divide-gray-700 xl:grid xl:grid-cols-4 xl:gap-x-6 xl:divide-y-0",
                            style: {
                                gridTemplateRows: "auto 1fr"
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("dl", {
                                    className: "pt-6 pb-10 xl:border-b xl:border-gray-200 xl:pt-11 xl:dark:border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dt", {
                                            className: "sr-only",
                                            children: "Authors"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dd", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("ul", {
                                                className: "flex justify-center space-x-8 sm:space-x-12 xl:block xl:space-x-0 xl:space-y-8",
                                                children: authorDetails.map(function(author) {
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("li", {
                                                        className: "flex items-center space-x-2",
                                                        children: [
                                                            author.avatar && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                                src: author.avatar,
                                                                width: "38px",
                                                                height: "38px",
                                                                alt: "avatar",
                                                                className: "h-10 w-10 rounded-full"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("dl", {
                                                                className: "whitespace-nowrap text-sm font-medium leading-5",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dt", {
                                                                        className: "sr-only",
                                                                        children: "Name"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dd", {
                                                                        className: "text-gray-900 dark:text-gray-100",
                                                                        children: author.name
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dt", {
                                                                        className: "sr-only",
                                                                        children: "Twitter"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dd", {
                                                                        children: author.twitter && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                            href: author.twitter,
                                                                            className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                                            children: author.twitter.replace("https://twitter.com/", "@")
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }, author.name);
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                    className: "divide-y divide-gray-200 dark:divide-gray-700 xl:col-span-3 xl:row-span-2 xl:pb-0",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                            className: "prose max-w-none pt-10 pb-8 dark:prose-dark",
                                            children: children
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                            className: "pt-6 pb-6 text-sm text-gray-700 dark:text-gray-300",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    href: discussUrl(slug),
                                                    rel: "nofollow",
                                                    children: "Discuss on Twitter"
                                                }),
                                                " \u2022 ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    href: editUrl(fileName),
                                                    children: "View on GitHub"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_comments__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                            frontMatter: frontMatter
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("footer", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                            className: "divide-gray-200 text-sm font-medium leading-5 dark:divide-gray-700 xl:col-start-1 xl:row-start-2 xl:divide-y",
                                            children: [
                                                tags && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                                    className: "py-4 xl:py-8",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("h2", {
                                                            className: "text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400",
                                                            children: "Tags"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                                            className: "flex flex-wrap",
                                                            children: tags.map(function(tag) {
                                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Tag__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                                    text: tag
                                                                }, tag);
                                                            })
                                                        })
                                                    ]
                                                }),
                                                (next || prev) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                                    className: "flex justify-between py-4 xl:block xl:space-y-8 xl:py-8",
                                                    children: [
                                                        prev && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("h2", {
                                                                    className: "text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400",
                                                                    children: "Previous Article"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                                                    className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                        href: "/blog/".concat(prev.slug),
                                                                        children: prev.title
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        next && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("h2", {
                                                                    className: "text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400",
                                                                    children: "Next Article"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                                                    className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                        href: "/blog/".concat(next.slug),
                                                                        children: next.title
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                            className: "pt-4 xl:pt-8",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                href: "/blog",
                                                className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                children: "\u2190 Back to the blog"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 3168:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ PostLayout; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _components_Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7233);
/* harmony import */ var _components_PageTitle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(920);
/* harmony import */ var _components_SectionContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(890);
/* harmony import */ var _components_SEO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9831);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _lib_utils_formatDate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6232);
/* harmony import */ var _components_comments__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(896);
/* harmony import */ var _components_ScrollTopAndComment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7175);
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}









function PostLayout(param) {
    var frontMatter = param.frontMatter, authorDetails = param.authorDetails, next = param.next, prev = param.prev, children = param.children;
    var date = frontMatter.date, title = frontMatter.title;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(_components_SectionContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_SEO__WEBPACK_IMPORTED_MODULE_4__/* .BlogSEO */ .Uy, _objectSpread({
                url: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default().siteUrl), "/blog/").concat(frontMatter.slug)
            }, frontMatter)),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_ScrollTopAndComment__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("article", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("header", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                className: "space-y-1 border-b border-gray-200 pb-10 text-center dark:border-gray-700",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dl", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dt", {
                                                    className: "sr-only",
                                                    children: "Published on"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("dd", {
                                                    className: "text-base font-medium leading-6 text-gray-500 dark:text-gray-400",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("time", {
                                                        dateTime: date,
                                                        children: (0,_lib_utils_formatDate__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(date)
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_PageTitle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            children: title
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                            className: "divide-y divide-gray-200 pb-8 dark:divide-gray-700 xl:divide-y-0 ",
                            style: {
                                gridTemplateRows: "auto 1fr"
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                    className: "divide-y divide-gray-200 dark:divide-gray-700 xl:col-span-3 xl:row-span-2 xl:pb-0",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                        className: "prose max-w-none pt-10 pb-8 dark:prose-dark",
                                        children: children
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_comments__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    frontMatter: frontMatter
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("footer", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
                                        className: "flex flex-col text-sm font-medium sm:flex-row sm:justify-between sm:text-base",
                                        children: [
                                            prev && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                                className: "pt-4 xl:pt-8",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    href: "/blog/".concat(prev.slug),
                                                    className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                    children: [
                                                        "\u2190 ",
                                                        prev.title
                                                    ]
                                                })
                                            }),
                                            next && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                                                className: "pt-4 xl:pt-8",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(_components_Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    href: "/blog/".concat(next.slug),
                                                    className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                    children: [
                                                        next.title,
                                                        " \u2192"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 6232:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_0__);

var formatDate = function(date) {
    var options = {
        year: "numeric",
        month: "long",
        day: "numeric"
    };
    var now = new Date(date).toLocaleDateString((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_0___default().locale), options);
    return now;
};
/* harmony default export */ __webpack_exports__["Z"] = (formatDate);


/***/ }),

/***/ 4871:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var github_slugger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9671);
/* harmony import */ var github_slugger__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(github_slugger__WEBPACK_IMPORTED_MODULE_0__);

var kebabCase = function(str) {
    return (0,github_slugger__WEBPACK_IMPORTED_MODULE_0__.slug)(str);
};
/* harmony default export */ __webpack_exports__["Z"] = (kebabCase);


/***/ })

}]);
//# sourceMappingURL=712-7bccecff1ccacba3.js.map