"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[806],{

/***/ 8806:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1720);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(425);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);




var Utterances = function() {
    var ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true), enableLoadComments = ref[0], setEnabledLoadComments = ref[1];
    var ref1 = (0,next_themes__WEBPACK_IMPORTED_MODULE_2__/* .useTheme */ .F)(), theme = ref1.theme, resolvedTheme = ref1.resolvedTheme;
    var commentsTheme = theme === "dark" || resolvedTheme === "dark" ? (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.utterancesConfig.darkTheme) : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.utterancesConfig.theme);
    var COMMENTS_ID = "comments-container";
    var LoadComments = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function() {
        setEnabledLoadComments(false);
        var script = document.createElement("script");
        script.src = "https://utteranc.es/client.js";
        script.setAttribute("repo", (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.utterancesConfig.repo));
        script.setAttribute("issue-term", (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.utterancesConfig.issueTerm));
        script.setAttribute("label", (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.utterancesConfig.label));
        script.setAttribute("theme", commentsTheme);
        script.setAttribute("crossorigin", "anonymous");
        script.async = true;
        var comments1 = document.getElementById(COMMENTS_ID);
        if (comments1) comments1.appendChild(script);
        return function() {
            var comments = document.getElementById(COMMENTS_ID);
            if (comments) comments.innerHTML = "";
        };
    }, [
        commentsTheme
    ]);
    // Reload on theme change
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function() {
        var iframe = document.querySelector("iframe.utterances-frame");
        if (!iframe) return;
        LoadComments();
    }, [
        LoadComments
    ]);
    // Added `relative` to fix a weird bug with `utterances-frame` position
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
        className: "pt-6 pb-6 text-center text-gray-700 dark:text-gray-300",
        children: [
            enableLoadComments && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("button", {
                onClick: LoadComments,
                children: "Load Comments"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                className: "utterances-frame relative",
                id: COMMENTS_ID
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["default"] = (Utterances);


/***/ })

}]);
//# sourceMappingURL=806.607d80f080d162fb.js.map