"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[257],{

/***/ 257:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1720);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_2__);



var Disqus = function(param) {
    var frontMatter = param.frontMatter;
    var LoadComments = function LoadComments() {
        setEnabledLoadComments(false);
        window.disqus_config = function() {
            this.page.url = window.location.href;
            this.page.identifier = frontMatter.slug;
        };
        if (window.DISQUS === undefined) {
            var script = document.createElement("script");
            script.src = "https://" + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_2___default().comment.disqusConfig.shortname) + ".disqus.com/embed.js";
            script.setAttribute("data-timestamp", +new Date());
            script.setAttribute("crossorigin", "anonymous");
            script.async = true;
            document.body.appendChild(script);
        } else {
            window.DISQUS.reset({
                reload: true
            });
        }
    };
    var ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true), enableLoadComments = ref[0], setEnabledLoadComments = ref[1];
    var COMMENTS_ID = "disqus_thread";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
        className: "pt-6 pb-6 text-center text-gray-700 dark:text-gray-300",
        children: [
            enableLoadComments && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("button", {
                onClick: LoadComments,
                children: "Load Comments"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                className: "disqus-frame",
                id: COMMENTS_ID
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["default"] = (Disqus);


/***/ })

}]);
//# sourceMappingURL=257.d0c3fa7f7a97a701.js.map