(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[94],{

/***/ 6082:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/blog/[...slug]",
      function () {
        return __webpack_require__(9662);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 9662:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSG": function() { return /* binding */ __N_SSG; },
/* harmony export */   "default": function() { return /* binding */ Blog; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _components_PageTitle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(920);
/* harmony import */ var _components_MDXComponents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1712);



var DEFAULT_LAYOUT = "PostLayout";
var __N_SSG = true;
function Blog(param) {
    var post = param.post, authorDetails = param.authorDetails, prev = param.prev, next = param.next;
    var mdxSource = post.mdxSource, toc = post.toc, frontMatter = post.frontMatter;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: frontMatter.draft !== true ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_MDXComponents__WEBPACK_IMPORTED_MODULE_2__/* .MDXLayoutRenderer */ .J, {
            layout: frontMatter.layout || DEFAULT_LAYOUT,
            toc: toc,
            mdxSource: mdxSource,
            frontMatter: frontMatter,
            authorDetails: authorDetails,
            prev: prev,
            next: next
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
            className: "mt-24 text-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(_components_PageTitle__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                children: [
                    "Under Construction",
                    " ",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("span", {
                        role: "img",
                        "aria-label": "roadwork sign",
                        children: "\uD83D\uDEA7"
                    })
                ]
            })
        })
    });
};


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [675,410,712,888,179], function() { return __webpack_exec__(6082); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=[...slug]-c88190431f69ad1f.js.map