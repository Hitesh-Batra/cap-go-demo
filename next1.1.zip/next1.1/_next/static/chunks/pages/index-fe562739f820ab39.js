(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[405],{

/***/ 8581:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/",
      function () {
        return __webpack_require__(4369);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 7726:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": function() { return /* binding */ BlogNewsletterForm; }
/* harmony export */ });
/* harmony import */ var _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4051);
/* harmony import */ var _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7320);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1720);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}




var NewsletterForm = function(param) {
    var _title = param.title, title = _title === void 0 ? "Subscribe to the newsletter" : _title;
    var inputEl = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    var ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false), error1 = ref[0], setError = ref[1];
    var ref1 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""), message = ref1[0], setMessage = ref1[1];
    var ref2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false), subscribed = ref2[0], setSubscribed = ref2[1];
    var subscribe = function() {
        var _ref = _asyncToGenerator(_Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().mark(function _callee(e) {
            var res, error;
            return _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().wrap(function _callee$(_ctx) {
                while(1)switch(_ctx.prev = _ctx.next){
                    case 0:
                        e.preventDefault();
                        _ctx.next = 3;
                        return fetch("/api/".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().newsletter.provider)), {
                            body: JSON.stringify({
                                email: inputEl.current.value
                            }),
                            headers: {
                                "Content-Type": "application/json"
                            },
                            method: "POST"
                        });
                    case 3:
                        res = _ctx.sent;
                        _ctx.next = 6;
                        return res.json();
                    case 6:
                        error = _ctx.sent.error;
                        if (!error) {
                            _ctx.next = 11;
                            break;
                        }
                        setError(true);
                        setMessage("Your e-mail address is invalid or you are already subscribed!");
                        return _ctx.abrupt("return");
                    case 11:
                        inputEl.current.value = "";
                        setError(false);
                        setSubscribed(true);
                        setMessage("Successfully! \uD83C\uDF89 You are now subscribed.");
                    case 15:
                    case "end":
                        return _ctx.stop();
                }
            }, _callee);
        }));
        return function subscribe(e) {
            return _ref.apply(this, arguments);
        };
    }();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                className: "pb-1 text-lg font-semibold text-gray-800 dark:text-gray-100",
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("form", {
                className: "flex flex-col sm:flex-row",
                onSubmit: subscribe,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("label", {
                                className: "sr-only",
                                htmlFor: "email-input",
                                children: "Email address"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("input", {
                                autoComplete: "email",
                                className: "w-72 rounded-md px-4 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-primary-600 dark:bg-black",
                                id: "email-input",
                                name: "email",
                                placeholder: subscribed ? "You're subscribed !  \uD83C\uDF89" : "Enter your email",
                                ref: inputEl,
                                required: true,
                                type: "email",
                                disabled: subscribed
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                        className: "mt-2 flex w-full rounded-md shadow-sm sm:mt-0 sm:ml-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("button", {
                            className: "w-full rounded-md bg-primary-500 py-2 px-4 font-medium text-white sm:py-0 ".concat(subscribed ? "cursor-default" : "hover:bg-primary-700 dark:hover:bg-primary-400", " focus:outline-none focus:ring-2 focus:ring-primary-600 focus:ring-offset-2 dark:ring-offset-black"),
                            type: "submit",
                            disabled: subscribed,
                            children: subscribed ? "Thank you!" : "Sign up"
                        })
                    })
                ]
            }),
            error1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                className: "w-72 pt-2 text-sm text-red-500 dark:text-red-400 sm:w-96",
                children: message
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["Z"] = (NewsletterForm);
var BlogNewsletterForm = function(param) {
    var title = param.title;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
        className: "flex items-center justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
            className: "bg-gray-100 p-6 dark:bg-gray-800 sm:px-14 sm:py-8",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(NewsletterForm, {
                title: title
            })
        })
    });
};


/***/ }),

/***/ 9831:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TQ": function() { return /* binding */ PageSEO; },
/* harmony export */   "$t": function() { return /* binding */ TagSEO; },
/* harmony export */   "Uy": function() { return /* binding */ BlogSEO; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9008);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1163);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);




var CommonSEO = function(param1) {
    var title = param1.title, description = param1.description, ogType = param1.ogType, ogImage = param1.ogImage, twImage = param1.twImage, canonicalUrl = param1.canonicalUrl;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("title", {
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "robots",
                content: "follow, index"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:url",
                content: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:type",
                content: ogType
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:site_name",
                content: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().title)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:title",
                content: title
            }),
            ogImage.constructor.name === "Array" ? ogImage.map(function(param) {
                var url = param.url;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                    property: "og:image",
                    content: url
                }, url);
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:image",
                content: ogImage
            }, ogImage),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:site",
                content: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().twitter)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:title",
                content: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:image",
                content: twImage
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("link", {
                rel: "canonical",
                href: canonicalUrl ? canonicalUrl : "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath)
            })
        ]
    });
};
var PageSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var twImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
        title: title,
        description: description,
        ogType: "website",
        ogImage: ogImageUrl,
        twImage: twImageUrl
    });
};
var TagSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var twImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
                title: title,
                description: description,
                ogType: "website",
                ogImage: ogImageUrl,
                twImage: twImageUrl
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("link", {
                    rel: "alternate",
                    type: "application/rss+xml",
                    title: "".concat(description, " - RSS feed"),
                    href: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath, "/feed.xml")
                })
            })
        ]
    });
};
var BlogSEO = function(param) {
    var authorDetails = param.authorDetails, title = param.title, summary = param.summary, date = param.date, lastmod = param.lastmod, url = param.url, _images = param.images, images = _images === void 0 ? [] : _images, canonicalUrl = param.canonicalUrl;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    var publishedAt = new Date(date).toISOString();
    var modifiedAt = new Date(lastmod || date).toISOString();
    var imagesArr = images.length === 0 ? [
        (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner)
    ] : typeof images === "string" ? [
        images
    ] : images;
    var featuredImages = imagesArr.map(function(img) {
        return {
            "@type": "ImageObject",
            url: img.includes("http") ? img : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + img
        };
    });
    var authorList;
    if (authorDetails) {
        authorList = authorDetails.map(function(author) {
            return {
                "@type": "Person",
                name: author.name
            };
        });
    } else {
        authorList = {
            "@type": "Person",
            name: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().author)
        };
    }
    var structuredData = {
        "@context": "https://schema.org",
        "@type": "Article",
        mainEntityOfPage: {
            "@type": "WebPage",
            "@id": url
        },
        headline: title,
        image: featuredImages,
        datePublished: publishedAt,
        dateModified: modifiedAt,
        author: authorList,
        publisher: {
            "@type": "Organization",
            name: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().author),
            logo: {
                "@type": "ImageObject",
                url: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteLogo))
            }
        },
        description: summary
    };
    var twImageUrl = featuredImages[0].url;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
                title: title,
                description: summary,
                ogType: "article",
                ogImage: featuredImages,
                twImage: twImageUrl,
                canonicalUrl: canonicalUrl
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: [
                    date && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                        property: "article:published_time",
                        content: publishedAt
                    }),
                    lastmod && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                        property: "article:modified_time",
                        content: modifiedAt
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(structuredData, null, 2)
                        }
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 9019:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _lib_utils_kebabCase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4871);



var Tag = function(param) {
    var text = param.text;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
        href: "/tags/".concat((0,_lib_utils_kebabCase__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(text)),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("a", {
            className: "mr-3 text-sm font-medium uppercase text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
            children: text.split(" ").join("-")
        })
    });
};
/* harmony default export */ __webpack_exports__["Z"] = (Tag);


/***/ }),

/***/ 6232:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_0__);

var formatDate = function(date) {
    var options = {
        year: "numeric",
        month: "long",
        day: "numeric"
    };
    var now = new Date(date).toLocaleDateString((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_0___default().locale), options);
    return now;
};
/* harmony default export */ __webpack_exports__["Z"] = (formatDate);


/***/ }),

/***/ 4871:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var github_slugger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9671);
/* harmony import */ var github_slugger__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(github_slugger__WEBPACK_IMPORTED_MODULE_0__);

var kebabCase = function(str) {
    return (0,github_slugger__WEBPACK_IMPORTED_MODULE_0__.slug)(str);
};
/* harmony default export */ __webpack_exports__["Z"] = (kebabCase);


/***/ }),

/***/ 4369:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSG": function() { return /* binding */ __N_SSG; },
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4051);
/* harmony import */ var _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7320);
/* harmony import */ var _components_Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7233);
/* harmony import */ var _components_SEO__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9831);
/* harmony import */ var _components_Tag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9019);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _lib_utils_formatDate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6232);
/* harmony import */ var _components_NewsletterForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7726);
/* harmony import */ var _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5767);
/* harmony import */ var _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(125);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5137);
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}


/* eslint-disable no-undef */ 






//import type { BundleInfo } from '@capgo/capacitor-updater'


//CapacitorUpdater.notifyAppReady()
// const version = await CapacitorUpdater.download({
//   url: 'https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Hitesh-Batra/cap-go-demo/blob/main/nextjs.zip',
// })
//await CapacitorUpdater.set(version); // sets the new version, and reloads the app
//console.log(version)
_capacitor_app__WEBPACK_IMPORTED_MODULE_10__/* .App.addListener */ .g.addListener("appStateChange", function() {
    var _ref = _asyncToGenerator(_Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().mark(function _callee(state) {
        return _Users_hbatra_projects_capacitor_poc_node_modules_next_dist_compiled_regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_0___default().wrap(function _callee$(_ctx) {
            while(1)switch(_ctx.prev = _ctx.next){
                case 0:
                    if (!state.isActive) {
                        _ctx.next = 4;
                        break;
                    }
                    _ctx.next = 3;
                    return _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_8__/* .CapacitorUpdater.download */ .O.download({
                        url: "https://github.com/Hitesh-Batra/cap-go-demo/raw/main/nextjs.zip",
                        version: "0.0.3"
                    });
                case 3:
                    // Ensure download occurs while the app is active, or download may fail
                    version = _ctx.sent;
                case 4:
                    console.log("version---->", version);
                    if (!(!state.isActive && version)) {
                        _ctx.next = 16;
                        break;
                    }
                    // Activate the update when the application is sent to background
                    _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_9__/* .SplashScreen.show */ .c.show();
                    _ctx.prev = 7;
                    _ctx.next = 10;
                    return _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_8__/* .CapacitorUpdater.set */ .O.set(version);
                case 10:
                    _ctx.next = 16;
                    break;
                case 12:
                    _ctx.prev = 12;
                    _ctx.t0 = _ctx["catch"](7);
                    console.log("exceptionVar", _ctx.t0);
                    _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_9__/* .SplashScreen.hide */ .c.hide() // Hide the splash screen again if something went wrong
                    ;
                case 16:
                case "end":
                    return _ctx.stop();
            }
        }, _callee, null, [
            [
                7,
                12
            ]
        ]);
    }));
    return function(state) {
        return _ref.apply(this, arguments);
    };
}());
// let data: BundleInfo | null = null
// App.addListener('appStateChange', async (state) => {
//   console.log('appStateChange', state)
//   if (state.isActive) {
//     console.log('getLatest')
//     // Do the download during user active app time to prevent failed download
//     const latest = await CapacitorUpdater.getLatest()
//     console.log('latest', latest)
//     if (latest.url) {
//       data = await CapacitorUpdater.download({
//         url: latest.url,
//         version: latest.version,
//       })
//       // eslint-disable-next-line no-undef
//       console.log('download', data)
//     }
//   }
//   if (!state.isActive) {
//     console.log('set')
//     // Do the switch when user leave app or when you want
//     SplashScreen.show()
//     try {
//       //await CapacitorUpdater.set({ id: data.id })
//     } catch (err) {
//       console.log(err)
//       SplashScreen.hide() // in case the set fail, otherwise the new app will have to hide it
//     }
//   }
// })
_capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_8__/* .CapacitorUpdater.addListener */ .O.addListener("majorAvailable", function(info) {
    console.log("majorAvailable was fired", info.version);
});
var MAX_DISPLAY = 5;
var __N_SSG = true;
function Home(param) {
    var posts = param.posts;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(_components_SEO__WEBPACK_IMPORTED_MODULE_3__/* .PageSEO */ .TQ, {
                title: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default().title),
                description: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default().description)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                className: "divide-y divide-gray-200 dark:divide-gray-700",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                        className: "space-y-2 pt-6 pb-8 md:space-y-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("h1", {
                                className: "text-3xl font-extrabold leading-9 tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl sm:leading-10 md:text-6xl md:leading-14",
                                children: "Check Capgo with the new frontend"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("p", {
                                className: "text-lg leading-7 text-gray-500 dark:text-gray-400",
                                children: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default().description)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("ul", {
                        className: "divide-y divide-gray-200 dark:divide-gray-700",
                        children: [
                            !posts.length && "No posts found.",
                            posts.slice(0, MAX_DISPLAY).map(function(frontMatter) {
                                var slug = frontMatter.slug, date = frontMatter.date, title = frontMatter.title, summary = frontMatter.summary, tags = frontMatter.tags;
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("li", {
                                    className: "py-12",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("article", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                                            className: "space-y-2 xl:grid xl:grid-cols-4 xl:items-baseline xl:space-y-0",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("dl", {
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("dt", {
                                                            className: "sr-only",
                                                            children: "Published on"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("dd", {
                                                            className: "text-base font-medium leading-6 text-gray-500 dark:text-gray-400",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("time", {
                                                                dateTime: date,
                                                                children: (0,_lib_utils_formatDate__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(date)
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                                                    className: "space-y-5 xl:col-span-3",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                                                            className: "space-y-6",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsxs */ .BX)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("h2", {
                                                                            className: "text-2xl font-bold leading-8 tracking-tight",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                href: "/blog/".concat(slug),
                                                                                className: "text-gray-900 dark:text-gray-100",
                                                                                children: title
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                                                                            className: "flex flex-wrap",
                                                                            children: tags.map(function(tag) {
                                                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(_components_Tag__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                                                    text: tag
                                                                                }, tag);
                                                                            })
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                                                                    className: "prose max-w-none text-gray-500 dark:text-gray-400",
                                                                    children: summary
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                                                            className: "text-base font-medium leading-6",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/blog/".concat(slug),
                                                                className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                                                                "aria-label": 'Read "'.concat(title, '"'),
                                                                children: "Read more \u2192"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                }, slug);
                            })
                        ]
                    })
                ]
            }),
            posts.length > MAX_DISPLAY && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                className: "flex justify-end text-base font-medium leading-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(_components_Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    href: "/blog",
                    className: "text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                    "aria-label": "all posts",
                    children: "All Posts \u2192"
                })
            }),
            (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_5___default().newsletter.provider) !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)("div", {
                className: "flex items-center justify-center pt-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__/* .jsx */ .tZ)(_components_NewsletterForm__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
            })
        ]
    });
};


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [989,888,179], function() { return __webpack_exec__(8581); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=index-fe562739f820ab39.js.map