(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[888],{

/***/ 425:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": function() { return /* binding */ f; },
/* harmony export */   "F": function() { return /* binding */ d; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1720);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9008);
var s=(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({setTheme:function(e){},themes:[]}),d=function(){return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(s)},u=["light","dark"],l="(prefers-color-scheme: dark)",f=function(t){var n=t.forcedTheme,c=t.disableTransitionOnChange,m=void 0!==c&&c,d=t.enableSystem,f=void 0===d||d,g=t.enableColorScheme,T=void 0===g||g,w=t.storageKey,S=void 0===w?"theme":w,b=t.themes,E=void 0===b?["light","dark"]:b,k=t.defaultTheme,x=void 0===k?f?"system":"light":k,L=t.attribute,I=void 0===L?"data-theme":L,C=t.value,M=t.children,_=(0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(function(){return v(S,x)}),O=_[0],H=_[1],K=(0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(function(){return v(S)}),N=K[0],j=K[1],A=C?Object.values(C):E,J=(0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(e){var t=p(e);j(t),"system"!==O||n||z(t,!1)},[O,n]),P=(0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(J);P.current=J;var z=(0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(e,t,n){void 0===t&&(t=!0),void 0===n&&(n=!0);var r=(null==C?void 0:C[e])||e,o=m&&n?y():null;if(t)try{localStorage.setItem(S,e)}catch(e){}if("system"===e&&f){var i=p();r=(null==C?void 0:C[i])||i}if(n){var a,c=document.documentElement;"class"===I?((a=c.classList).remove.apply(a,A),c.classList.add(r)):c.setAttribute(I,r),null==o||o()}},[]);(0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function(){var e=function(){return P.current.apply(P,[].slice.call(arguments))},t=window.matchMedia(l);return t.addListener(e),e(t),function(){return t.removeListener(e)}},[]);var V=(0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(e){n?z(e,!0,!1):z(e),H(e)},[n]);return (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function(){var e=function(e){e.key===S&&V(e.newValue)};return window.addEventListener("storage",e),function(){return window.removeEventListener("storage",e)}},[V]),(0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function(){if(T){var e=n&&u.includes(n)?n:O&&u.includes(O)?O:"system"===O&&N||null;document.documentElement.style.setProperty("color-scheme",e)}},[T,O,N,n]),react__WEBPACK_IMPORTED_MODULE_0__["default"].createElement(s.Provider,{value:{theme:O,setTheme:V,forcedTheme:n,resolvedTheme:"system"===O?N:O,themes:f?[].concat(E,["system"]):E,systemTheme:f?N:void 0}},react__WEBPACK_IMPORTED_MODULE_0__["default"].createElement(h,{forcedTheme:n,storageKey:S,attribute:I,value:C,enableSystem:f,defaultTheme:x,attrs:A}),M)},h=(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function(t){var n=t.forcedTheme,r=t.storageKey,o=t.attribute,i=t.enableSystem,a=t.defaultTheme,c=t.value,s="class"===o?"var d=document.documentElement.classList;d.remove("+t.attrs.map(function(e){return"'"+e+"'"}).join(",")+");":"var d=document.documentElement;",d=function(e,t){e=(null==c?void 0:c[e])||e;var n=t?e:"'"+e+"'";return"class"===o?"d.add("+n+")":"d.setAttribute('"+o+"', "+n+")"},u="system"===a;return react__WEBPACK_IMPORTED_MODULE_0__["default"].createElement(next_head__WEBPACK_IMPORTED_MODULE_1__["default"],null,react__WEBPACK_IMPORTED_MODULE_0__["default"].createElement("script",n?{key:"next-themes-script",dangerouslySetInnerHTML:{__html:"!function(){"+s+d(n)+"}()"}}:i?{key:"next-themes-script",dangerouslySetInnerHTML:{__html:"!function(){try {"+s+"var e=localStorage.getItem('"+r+"');"+(u?"":d(a)+";")+'if("system"===e||(!e&&'+u+')){var t="'+l+'",m=window.matchMedia(t);m.media!==t||m.matches?'+d("dark")+":"+d("light")+"}else if(e) "+(c?"var x="+JSON.stringify(c)+";":"")+d(c?"x[e]":"e",!0)+"}catch(e){}}()"}}:{key:"next-themes-script",dangerouslySetInnerHTML:{__html:"!function(){try{"+s+'var e=localStorage.getItem("'+r+'");if(e){'+(c?"var x="+JSON.stringify(c)+";":"")+d(c?"x[e]":"e",!0)+"}else{"+d(a)+";}}catch(t){}}();"}}))},function(e,t){return e.forcedTheme===t.forcedTheme}),v=function(e,t){if("undefined"!=typeof window){var n;try{n=localStorage.getItem(e)||void 0}catch(e){}return n||t}},y=function(){var e=document.createElement("style");return e.appendChild(document.createTextNode("*{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")),document.head.appendChild(e),function(){window.getComputedStyle(document.body),setTimeout(function(){document.head.removeChild(e)},1)}},p=function(e){return e||(e=window.matchMedia(l)),e.matches?"dark":"light"};


/***/ }),

/***/ 3454:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";

var ref, ref1;
module.exports = ((ref = __webpack_require__.g.process) === null || ref === void 0 ? void 0 : ref.env) && typeof ((ref1 = __webpack_require__.g.process) === null || ref1 === void 0 ? void 0 : ref1.env) === 'object' ? __webpack_require__.g.process : __webpack_require__(7663);

//# sourceMappingURL=process.js.map

/***/ }),

/***/ 1780:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/_app",
      function () {
        return __webpack_require__(218);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 7233:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}

/* eslint-disable jsx-a11y/anchor-has-content */ 
var CustomLink = function(_param) {
    var href = _param.href, rest = _objectWithoutProperties(_param, [
        "href"
    ]);
    var isInternalLink = href && href.startsWith("/");
    var isAnchorLink = href && href.startsWith("#");
    if (isInternalLink) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
            href: href,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("a", _objectSpread({}, rest))
        });
    }
    if (isAnchorLink) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("a", _objectSpread({
            href: href
        }, rest));
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("a", _objectSpread({
        target: "_blank",
        rel: "noopener noreferrer",
        href: href
    }, rest));
};
/* harmony default export */ __webpack_exports__["Z"] = (CustomLink);


/***/ }),

/***/ 890:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ SectionContainer; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);

function SectionContainer(param) {
    var children = param.children;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
        className: "mx-auto max-w-3xl px-4 sm:px-6 xl:max-w-5xl xl:px-0",
        children: children
    });
};


/***/ }),

/***/ 2557:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ social_icons; }
});

// EXTERNAL MODULE: ./node_modules/preact/compat/jsx-runtime.mjs
var jsx_runtime = __webpack_require__(7320);
// EXTERNAL MODULE: ./node_modules/preact/compat/dist/compat.module.js + 1 modules
var compat_module = __webpack_require__(1720);
;// CONCATENATED MODULE: ./components/social-icons/mail.svg
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgMail = function SvgMail(props) {
  return /*#__PURE__*/compat_module.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 20 20"
  }, props), _path || (_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M2.003 5.884 10 9.882l7.997-3.998A2 2 0 0 0 16 4H4a2 2 0 0 0-1.997 1.884z"
  })), _path2 || (_path2 = /*#__PURE__*/compat_module.createElement("path", {
    d: "m18 8.118-8 4-8-4V14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8.118z"
  })));
};

/* harmony default export */ var mail = (SvgMail);
;// CONCATENATED MODULE: ./components/social-icons/github.svg
var github_path;

function github_extends() { github_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return github_extends.apply(this, arguments); }



var SvgGithub = function SvgGithub(props) {
  return /*#__PURE__*/compat_module.createElement("svg", github_extends({
    viewBox: "0 0 24 24",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), github_path || (github_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"
  })));
};

/* harmony default export */ var github = (SvgGithub);
;// CONCATENATED MODULE: ./components/social-icons/facebook.svg
var facebook_path;

function facebook_extends() { facebook_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return facebook_extends.apply(this, arguments); }



var SvgFacebook = function SvgFacebook(props) {
  return /*#__PURE__*/compat_module.createElement("svg", facebook_extends({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24"
  }, props), facebook_path || (facebook_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
  })));
};

/* harmony default export */ var facebook = (SvgFacebook);
;// CONCATENATED MODULE: ./components/social-icons/youtube.svg
var youtube_path;

function youtube_extends() { youtube_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return youtube_extends.apply(this, arguments); }



var SvgYoutube = function SvgYoutube(props) {
  return /*#__PURE__*/compat_module.createElement("svg", youtube_extends({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24"
  }, props), youtube_path || (youtube_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M23.499 6.203a3.008 3.008 0 0 0-2.089-2.089c-1.87-.501-9.4-.501-9.4-.501s-7.509-.01-9.399.501a3.008 3.008 0 0 0-2.088 2.09A31.258 31.26 0 0 0 0 12.01a31.258 31.26 0 0 0 .523 5.785 3.008 3.008 0 0 0 2.088 2.089c1.869.502 9.4.502 9.4.502s7.508 0 9.399-.502a3.008 3.008 0 0 0 2.089-2.09 31.258 31.26 0 0 0 .5-5.784 31.258 31.26 0 0 0-.5-5.808zm-13.891 9.4V8.407l6.266 3.604z"
  })));
};

/* harmony default export */ var youtube = (SvgYoutube);
;// CONCATENATED MODULE: ./components/social-icons/linkedin.svg
var linkedin_path;

function linkedin_extends() { linkedin_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return linkedin_extends.apply(this, arguments); }



var SvgLinkedin = function SvgLinkedin(props) {
  return /*#__PURE__*/compat_module.createElement("svg", linkedin_extends({
    viewBox: "0 0 24 24",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), linkedin_path || (linkedin_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
  })));
};

/* harmony default export */ var linkedin = (SvgLinkedin);
;// CONCATENATED MODULE: ./components/social-icons/twitter.svg
var twitter_path;

function twitter_extends() { twitter_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return twitter_extends.apply(this, arguments); }



var SvgTwitter = function SvgTwitter(props) {
  return /*#__PURE__*/compat_module.createElement("svg", twitter_extends({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24"
  }, props), twitter_path || (twitter_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M23.953 4.57a10 10 0 0 1-2.825.775 4.958 4.958 0 0 0 2.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 0 0-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 0 0-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 0 1-2.228-.616v.06a4.923 4.923 0 0 0 3.946 4.827 4.996 4.996 0 0 1-2.212.085 4.936 4.936 0 0 0 4.604 3.417 9.867 9.867 0 0 1-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 0 0 7.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0 0 24 4.59z"
  })));
};

/* harmony default export */ var twitter = (SvgTwitter);
;// CONCATENATED MODULE: ./components/social-icons/index.js







// Icons taken from: https://simpleicons.org/
var components = {
    mail: mail,
    github: github,
    facebook: facebook,
    youtube: youtube,
    linkedin: linkedin,
    twitter: twitter
};
var SocialIcon = function(param) {
    var kind = param.kind, href = param.href, _size = param.size, size = _size === void 0 ? 8 : _size;
    if (!href || kind === "mail" && !/^mailto:\w+([.-]?\w+)@\w+([.-]?\w+)(.\w{2,3})+$/.test(href)) return null;
    var SocialSvg = components[kind];
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("a", {
        className: "text-sm text-gray-500 transition hover:text-gray-600",
        target: "_blank",
        rel: "noopener noreferrer",
        href: href,
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("span", {
                className: "sr-only",
                children: kind
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(SocialSvg, {
                className: "fill-current text-gray-700 hover:text-blue-500 dark:text-gray-200 dark:hover:text-blue-400 h-".concat(size, " w-").concat(size)
            })
        ]
    });
};
/* harmony default export */ var social_icons = (SocialIcon);


/***/ }),

/***/ 1576:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/* provided dependency */ var process = __webpack_require__(3454);

var siteMetadata = {
    title: "Next.js Starter Blog",
    author: "Tails Azimuth",
    headerTitle: "TailwindBlog",
    description: "A blog created with Next.js and Tailwind.css",
    language: "en-us",
    theme: "system",
    siteUrl: "https://tailwind-nextjs-starter-blog.vercel.app",
    siteRepo: "https://github.com/timlrx/tailwind-nextjs-starter-blog",
    siteLogo: "/static/images/logo.png",
    image: "/static/images/avatar.png",
    socialBanner: "/static/images/twitter-card.png",
    email: "address@yoursite.com",
    github: "https://github.com",
    twitter: "https://twitter.com/Twitter",
    facebook: "https://facebook.com",
    youtube: "https://youtube.com",
    linkedin: "https://www.linkedin.com",
    locale: "en-US",
    analytics: {
        // If you want to use an analytics provider you have to add it to the
        // content security policy in the `next.config.js` file.
        // supports plausible, simpleAnalytics, umami or googleAnalytics
        plausibleDataDomain: "",
        simpleAnalytics: false,
        umamiWebsiteId: "",
        googleAnalyticsId: "",
        posthogAnalyticsId: ""
    },
    newsletter: {
        // supports mailchimp, buttondown, convertkit, klaviyo, revue, emailoctopus
        // Please add your .env file and modify it according to your selection
        provider: "buttondown"
    },
    comment: {
        // If you want to use a commenting system other than giscus you have to add it to the
        // content security policy in the `next.config.js` file.
        // Select a provider and use the environment variables associated to it
        // https://vercel.com/docs/environment-variables
        provider: "giscus",
        giscusConfig: {
            // Visit the link below, and follow the steps in the 'configuration' section
            // https://giscus.app/
            repo: process.env.NEXT_PUBLIC_GISCUS_REPO,
            repositoryId: process.env.NEXT_PUBLIC_GISCUS_REPOSITORY_ID,
            category: process.env.NEXT_PUBLIC_GISCUS_CATEGORY,
            categoryId: process.env.NEXT_PUBLIC_GISCUS_CATEGORY_ID,
            mapping: "pathname",
            reactions: "1",
            // Send discussion metadata periodically to the parent window: 1 = enable / 0 = disable
            metadata: "0",
            // theme example: light, dark, dark_dimmed, dark_high_contrast
            // transparent_dark, preferred_color_scheme, custom
            theme: "light",
            // Place the comment box above the comments. options: bottom, top
            inputPosition: "bottom",
            // Choose the language giscus will be displayed in. options: en, es, zh-CN, zh-TW, ko, ja etc
            lang: "en",
            // theme when dark mode
            darkTheme: "transparent_dark",
            // If the theme option above is set to 'custom`
            // please provide a link below to your custom theme css file.
            // example: https://giscus.app/themes/custom_example.css
            themeURL: ""
        },
        utterancesConfig: {
            // Visit the link below, and follow the steps in the 'configuration' section
            // https://utteranc.es/
            repo: process.env.NEXT_PUBLIC_UTTERANCES_REPO,
            issueTerm: "",
            label: "",
            // theme example: github-light, github-dark, preferred-color-scheme
            // github-dark-orange, icy-dark, dark-blue, photon-dark, boxy-light
            theme: "",
            // theme when dark mode
            darkTheme: ""
        },
        disqusConfig: {
            // https://help.disqus.com/en/articles/1717111-what-s-a-shortname
            shortname: process.env.NEXT_PUBLIC_DISQUS_SHORTNAME
        }
    }
};
module.exports = siteMetadata;


/***/ }),

/***/ 1551:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";
var __webpack_unused_export__;

function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
var _typeof = function(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
};
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
__webpack_unused_export__ = ({
    value: true
});
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(1720));
var _router = __webpack_require__(1003);
var _router1 = __webpack_require__(880);
var _useIntersection = __webpack_require__(9246);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var prefetched = {};
function prefetch(router, href, as, options) {
    if ( false || !router) return;
    if (!(0, _router).isLocalURL(href)) return;
    // Prefetch the JSON page if asked (only in the client)
    // We need to handle a prefetch error here since we may be
    // loading with priority which can reject but we don't
    // want to force navigation since this is only a prefetch
    router.prefetch(href, as, options).catch(function(err) {
        if (false) {}
    });
    var curLocale = options && typeof options.locale !== "undefined" ? options.locale : router && router.locale;
    // Join on an invalid URI character
    prefetched[href + "%" + as + (curLocale ? "%" + curLocale : "")] = true;
}
function isModifiedEvent(event) {
    var target = event.currentTarget.target;
    return target && target !== "_self" || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.nativeEvent && event.nativeEvent.which === 2;
}
function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
    var nodeName = e.currentTarget.nodeName;
    // anchors inside an svg have a lowercase nodeName
    var isAnchorNodeName = nodeName.toUpperCase() === "A";
    if (isAnchorNodeName && (isModifiedEvent(e) || !(0, _router).isLocalURL(href))) {
        // ignore click for browser’s default behavior
        return;
    }
    e.preventDefault();
    // replace state instead of push if prop is present
    router[replace ? "replace" : "push"](href, as, {
        shallow: shallow,
        locale: locale,
        scroll: scroll
    });
}
function Link(props) {
    if (false) { var hasWarned, optionalProps, optionalPropsGuard, requiredProps, requiredPropsGuard, createPropError; }
    var p = props.prefetch !== false;
    var router = (0, _router1).useRouter();
    var ref2 = _react.default.useMemo(function() {
        var ref = _slicedToArray((0, _router).resolveHref(router, props.href, true), 2), resolvedHref = ref[0], resolvedAs = ref[1];
        return {
            href: resolvedHref,
            as: props.as ? (0, _router).resolveHref(router, props.as) : resolvedAs || resolvedHref
        };
    }, [
        router,
        props.href,
        props.as
    ]), href = ref2.href, as = ref2.as;
    var children = props.children, replace = props.replace, shallow = props.shallow, scroll = props.scroll, locale = props.locale;
    if (typeof children === "string") {
        children = /*#__PURE__*/ _react.default.createElement("a", null, children);
    }
    // This will return the first child, if multiple are provided it will throw an error
    var child;
    if (false) {} else {
        child = _react.default.Children.only(children);
    }
    var childRef = child && typeof child === "object" && child.ref;
    var ref1 = _slicedToArray((0, _useIntersection).useIntersection({
        rootMargin: "200px"
    }), 2), setIntersectionRef = ref1[0], isVisible = ref1[1];
    var setRef = _react.default.useCallback(function(el) {
        setIntersectionRef(el);
        if (childRef) {
            if (typeof childRef === "function") childRef(el);
            else if (typeof childRef === "object") {
                childRef.current = el;
            }
        }
    }, [
        childRef,
        setIntersectionRef
    ]);
    _react.default.useEffect(function() {
        var shouldPrefetch = isVisible && p && (0, _router).isLocalURL(href);
        var curLocale = typeof locale !== "undefined" ? locale : router && router.locale;
        var isPrefetched = prefetched[href + "%" + as + (curLocale ? "%" + curLocale : "")];
        if (shouldPrefetch && !isPrefetched) {
            prefetch(router, href, as, {
                locale: curLocale
            });
        }
    }, [
        as,
        href,
        isVisible,
        locale,
        p,
        router
    ]);
    var childProps = {
        ref: setRef,
        onClick: function(e) {
            if (false) {}
            if (child.props && typeof child.props.onClick === "function") {
                child.props.onClick(e);
            }
            if (!e.defaultPrevented) {
                linkClicked(e, router, href, as, replace, shallow, scroll, locale);
            }
        }
    };
    childProps.onMouseEnter = function(e) {
        if (child.props && typeof child.props.onMouseEnter === "function") {
            child.props.onMouseEnter(e);
        }
        if ((0, _router).isLocalURL(href)) {
            prefetch(router, href, as, {
                priority: true
            });
        }
    };
    // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
    // defined, we specify the current 'href', so that repetition is not needed by the user
    if (props.passHref || child.type === "a" && !("href" in child.props)) {
        var curLocale1 = typeof locale !== "undefined" ? locale : router && router.locale;
        // we only render domain locales if we are currently on a domain locale
        // so that locale links are still visitable in development/preview envs
        var localeDomain = router && router.isLocaleDomain && (0, _router).getDomainLocale(as, curLocale1, router && router.locales, router && router.domainLocales);
        childProps.href = localeDomain || (0, _router).addBasePath((0, _router).addLocale(as, curLocale1, router && router.defaultLocale));
    }
    return /*#__PURE__*/ _react.default.cloneElement(child, childProps);
}
var _default = Link;
exports["default"] = _default; //# sourceMappingURL=link.js.map


/***/ }),

/***/ 9246:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.useIntersection = useIntersection;
var _react = __webpack_require__(1720);
var _requestIdleCallback = __webpack_require__(4686);
var hasIntersectionObserver = typeof IntersectionObserver !== "undefined";
function useIntersection(param) {
    var rootRef = param.rootRef, rootMargin = param.rootMargin, disabled = param.disabled;
    var isDisabled = disabled || !hasIntersectionObserver;
    var unobserve = (0, _react).useRef();
    var ref = _slicedToArray((0, _react).useState(false), 2), visible = ref[0], setVisible = ref[1];
    var ref1 = _slicedToArray((0, _react).useState(rootRef ? rootRef.current : null), 2), root = ref1[0], setRoot = ref1[1];
    var setRef = (0, _react).useCallback(function(el) {
        if (unobserve.current) {
            unobserve.current();
            unobserve.current = undefined;
        }
        if (isDisabled || visible) return;
        if (el && el.tagName) {
            unobserve.current = observe(el, function(isVisible) {
                return isVisible && setVisible(isVisible);
            }, {
                root: root,
                rootMargin: rootMargin
            });
        }
    }, [
        isDisabled,
        root,
        rootMargin,
        visible
    ]);
    (0, _react).useEffect(function() {
        if (!hasIntersectionObserver) {
            if (!visible) {
                var idleCallback = (0, _requestIdleCallback).requestIdleCallback(function() {
                    return setVisible(true);
                });
                return function() {
                    return (0, _requestIdleCallback).cancelIdleCallback(idleCallback);
                };
            }
        }
    }, [
        visible
    ]);
    (0, _react).useEffect(function() {
        if (rootRef) setRoot(rootRef.current);
    }, [
        rootRef
    ]);
    return [
        setRef,
        visible
    ];
}
function observe(element, callback, options) {
    var ref = createObserver(options), id = ref.id, observer = ref.observer, elements = ref.elements;
    elements.set(element, callback);
    observer.observe(element);
    return function unobserve() {
        elements.delete(element);
        observer.unobserve(element);
        // Destroy observer when there's nothing left to watch:
        if (elements.size === 0) {
            observer.disconnect();
            observers.delete(id);
            var index = idList.findIndex(function(obj) {
                return obj.root === id.root && obj.margin === id.margin;
            });
            if (index > -1) {
                idList.splice(index, 1);
            }
        }
    };
}
var observers = new Map();
var idList = [];
function createObserver(options) {
    var id = {
        root: options.root || null,
        margin: options.rootMargin || ""
    };
    var existing = idList.find(function(obj) {
        return obj.root === id.root && obj.margin === id.margin;
    });
    var instance;
    if (existing) {
        instance = observers.get(existing);
    } else {
        instance = observers.get(id);
        idList.push(id);
    }
    if (instance) {
        return instance;
    }
    var elements = new Map();
    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            var callback = elements.get(entry.target);
            var isVisible = entry.isIntersecting || entry.intersectionRatio > 0;
            if (callback && isVisible) {
                callback(isVisible);
            }
        });
    }, options);
    observers.set(id, instance = {
        id: id,
        observer: observer,
        elements: elements
    });
    return instance;
} //# sourceMappingURL=use-intersection.js.map


/***/ }),

/***/ 218:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ App; }
});

// EXTERNAL MODULE: ./node_modules/preact/compat/jsx-runtime.mjs
var jsx_runtime = __webpack_require__(7320);
// EXTERNAL MODULE: ./css/tailwind.css
var tailwind = __webpack_require__(2604);
// EXTERNAL MODULE: ./css/prism.css
var prism = __webpack_require__(7661);
// EXTERNAL MODULE: ./node_modules/katex/dist/katex.css
var katex = __webpack_require__(3941);
// EXTERNAL MODULE: ./node_modules/@fontsource/inter/variable-full.css
var variable_full = __webpack_require__(8102);
// EXTERNAL MODULE: ./node_modules/next-themes/dist/index.modern.js
var index_modern = __webpack_require__(425);
// EXTERNAL MODULE: ./node_modules/next/head.js
var head = __webpack_require__(9008);
// EXTERNAL MODULE: ./data/siteMetadata.js
var siteMetadata = __webpack_require__(1576);
var siteMetadata_default = /*#__PURE__*/__webpack_require__.n(siteMetadata);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
;// CONCATENATED MODULE: ./components/analytics/GoogleAnalytics.js



var GAScript = function() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
                strategy: "lazyOnload",
                src: "https://www.googletagmanager.com/gtag/js?id=".concat((siteMetadata_default()).analytics.googleAnalyticsId)
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
                strategy: "lazyOnload",
                id: "ga-script",
                children: "\n            window.dataLayer = window.dataLayer || [];\n            function gtag(){dataLayer.push(arguments);}\n            gtag('js', new Date());\n            gtag('config', '".concat((siteMetadata_default()).analytics.googleAnalyticsId, "', {\n              page_path: window.location.pathname,\n            });\n        ")
            })
        ]
    });
};
/* harmony default export */ var GoogleAnalytics = (GAScript);
// https://developers.google.com/analytics/devguides/collection/gtagjs/events
var logEvent = function(action, category, label, value) {
    var ref;
    (ref = window.gtag) === null || ref === void 0 ? void 0 : ref.call(window, "event", action, {
        event_category: category,
        event_label: label,
        value: value
    });
};

;// CONCATENATED MODULE: ./components/analytics/Plausible.js
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}
function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}



var PlausibleScript = function() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
                strategy: "lazyOnload",
                "data-domain": (siteMetadata_default()).analytics.plausibleDataDomain,
                src: "https://plausible.io/js/plausible.js"
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
                strategy: "lazyOnload",
                id: "plausible-script",
                children: "\n            window.plausible = window.plausible || function() { (window.plausible.q = window.plausible.q || []).push(arguments) }\n        "
            })
        ]
    });
};
/* harmony default export */ var Plausible = (PlausibleScript);
// https://plausible.io/docs/custom-event-goals
var Plausible_logEvent = function(eventName) {
    for(var _len = arguments.length, rest = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        rest[_key - 1] = arguments[_key];
    }
    var _ref;
    var ref;
    return (ref = window.plausible) === null || ref === void 0 ? void 0 : (_ref = ref).call.apply(_ref, [
        window,
        eventName
    ].concat(_toConsumableArray(rest)));
};

;// CONCATENATED MODULE: ./components/analytics/SimpleAnalytics.js


var SimpleAnalyticsScript = function() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
                strategy: "lazyOnload",
                id: "sa-script",
                children: "\n            window.sa_event=window.sa_event||function(){var a=[].slice.call(arguments);window.sa_event.q?window.sa_event.q.push(a):window.sa_event.q=[a]};\n        "
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
                strategy: "lazyOnload",
                src: "https://scripts.simpleanalyticscdn.com/latest.js"
            })
        ]
    });
};
// https://docs.simpleanalytics.com/events
var SimpleAnalytics_logEvent = function(eventName, callback) {
    if (callback) {
        var ref;
        return (ref = window.sa_event) === null || ref === void 0 ? void 0 : ref.call(window, eventName, callback);
    } else {
        var ref1;
        return (ref1 = window.sa_event) === null || ref1 === void 0 ? void 0 : ref1.call(window, eventName);
    }
};
/* harmony default export */ var SimpleAnalytics = (SimpleAnalyticsScript);

;// CONCATENATED MODULE: ./components/analytics/Umami.js



var UmamiScript = function() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(jsx_runtime/* Fragment */.HY, {
        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
            async: true,
            defer: true,
            "data-website-id": (siteMetadata_default()).analytics.umamiWebsiteId,
            src: "https://umami.example.com/umami.js" // Replace with your umami instance
        })
    });
};
/* harmony default export */ var Umami = (UmamiScript);

;// CONCATENATED MODULE: ./components/analytics/Posthog.js



var PosthogScript = function() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(jsx_runtime/* Fragment */.HY, {
        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(script["default"], {
            strategy: "lazyOnload",
            id: "posthog-script",
            children: '\n            !function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}(p=t.createElement("script")).type="text/javascript",p.async=!0,p.src=s.api_host+"/static/array.js",(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+".people (stub)"},o="capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);\n            posthog.init(\''.concat((siteMetadata_default()).analytics.posthogAnalyticsId, "',{api_host:'https://app.posthog.com'})\n        ")
        })
    });
};
/* harmony default export */ var Posthog = (PosthogScript);

;// CONCATENATED MODULE: ./components/analytics/index.js







var isProduction = "production" === "production";
var Analytics = function() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            isProduction && (siteMetadata_default()).analytics.plausibleDataDomain && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Plausible, {}),
            isProduction && (siteMetadata_default()).analytics.simpleAnalytics && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(SimpleAnalytics, {}),
            isProduction && (siteMetadata_default()).analytics.umamiWebsiteId && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Umami, {}),
            isProduction && (siteMetadata_default()).analytics.googleAnalyticsId && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(GoogleAnalytics, {}),
            isProduction && (siteMetadata_default()).analytics.posthogAnalyticsId && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Posthog, {})
        ]
    });
};
/* harmony default export */ var analytics = (Analytics);

;// CONCATENATED MODULE: ./data/headerNavLinks.js
var headerNavLinks = [
    {
        href: "/blog",
        title: "Blog"
    },
    {
        href: "/tags",
        title: "Tags"
    },
    {
        href: "/projects",
        title: "Projects"
    },
    {
        href: "/about",
        title: "About"
    }, 
];
/* harmony default export */ var data_headerNavLinks = (headerNavLinks);

// EXTERNAL MODULE: ./node_modules/preact/compat/dist/compat.module.js + 1 modules
var compat_module = __webpack_require__(1720);
;// CONCATENATED MODULE: ./data/logo.svg
var _path, _path2, _use, _use2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgLogo = function SvgLogo(props) {
  return /*#__PURE__*/compat_module.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    viewBox: "344.564 330.278 111.737 91.218",
    width: 53.87,
    height: 43.61
  }, props), /*#__PURE__*/compat_module.createElement("defs", null, /*#__PURE__*/compat_module.createElement("linearGradient", {
    id: "logo_svg__b",
    gradientUnits: "userSpaceOnUse",
    x1: 420.97,
    y1: 331.28,
    x2: 420.97,
    y2: 418.5
  }, /*#__PURE__*/compat_module.createElement("stop", {
    style: {
      stopColor: "#06b6d4",
      stopOpacity: 1
    },
    offset: "0%"
  }), /*#__PURE__*/compat_module.createElement("stop", {
    style: {
      stopColor: "#67e8f9",
      stopOpacity: 1
    },
    offset: "100%"
  })), /*#__PURE__*/compat_module.createElement("linearGradient", {
    id: "logo_svg__d",
    gradientUnits: "userSpaceOnUse",
    x1: 377.89,
    y1: 331.28,
    x2: 377.89,
    y2: 418.5
  }, /*#__PURE__*/compat_module.createElement("stop", {
    style: {
      stopColor: "#06b6d4",
      stopOpacity: 1
    },
    offset: "0%"
  }), /*#__PURE__*/compat_module.createElement("stop", {
    style: {
      stopColor: "#67e8f9",
      stopOpacity: 1
    },
    offset: "100%"
  })), _path || (_path = /*#__PURE__*/compat_module.createElement("path", {
    d: "M453.3 331.28v28.57l-64.66 58.65v-30.08l64.66-57.14Z",
    id: "logo_svg__a"
  })), _path2 || (_path2 = /*#__PURE__*/compat_module.createElement("path", {
    d: "M410.23 331.28v28.57l-64.67 58.65v-30.08l64.67-57.14Z",
    id: "logo_svg__c"
  }))), _use || (_use = /*#__PURE__*/compat_module.createElement("use", {
    xlinkHref: "#logo_svg__a",
    fill: "url(#logo_svg__b)"
  })), _use2 || (_use2 = /*#__PURE__*/compat_module.createElement("use", {
    xlinkHref: "#logo_svg__c",
    fill: "url(#logo_svg__d)"
  })));
};

/* harmony default export */ var logo = (SvgLogo);
// EXTERNAL MODULE: ./components/Link.js
var Link = __webpack_require__(7233);
// EXTERNAL MODULE: ./components/SectionContainer.js
var SectionContainer = __webpack_require__(890);
// EXTERNAL MODULE: ./components/social-icons/index.js + 6 modules
var social_icons = __webpack_require__(2557);
;// CONCATENATED MODULE: ./components/Footer.js




function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("footer", {
        children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
            className: "mt-16 flex flex-col items-center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                    className: "mb-3 flex space-x-4",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(social_icons/* default */.Z, {
                            kind: "mail",
                            href: "mailto:".concat((siteMetadata_default()).email),
                            size: "6"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(social_icons/* default */.Z, {
                            kind: "github",
                            href: (siteMetadata_default()).github,
                            size: "6"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(social_icons/* default */.Z, {
                            kind: "facebook",
                            href: (siteMetadata_default()).facebook,
                            size: "6"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(social_icons/* default */.Z, {
                            kind: "youtube",
                            href: (siteMetadata_default()).youtube,
                            size: "6"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(social_icons/* default */.Z, {
                            kind: "linkedin",
                            href: (siteMetadata_default()).linkedin,
                            size: "6"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(social_icons/* default */.Z, {
                            kind: "twitter",
                            href: (siteMetadata_default()).twitter,
                            size: "6"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                    className: "mb-2 flex space-x-2 text-sm text-gray-500 dark:text-gray-400",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                            children: (siteMetadata_default()).author
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                            children: " \u2022 "
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                            children: "\xa9 ".concat(new Date().getFullYear())
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                            children: " \u2022 "
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                            href: "/",
                            children: (siteMetadata_default()).title
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                    className: "mb-8 text-sm text-gray-500 dark:text-gray-400",
                    children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                        href: "https://github.com/timlrx/tailwind-nextjs-starter-blog",
                        children: "Tailwind Nextjs Theme"
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/MobileNav.js




var MobileNav = function() {
    var ref = (0,compat_module.useState)(false), navShow = ref[0], setNavShow = ref[1];
    var onToggleNav = function() {
        setNavShow(function(status) {
            if (status) {
                document.body.style.overflow = "auto";
            } else {
                // Prevent scrolling
                document.body.style.overflow = "hidden";
            }
            return !status;
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
        className: "sm:hidden",
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                type: "button",
                className: "ml-1 mr-1 h-8 w-8 rounded py-1",
                "aria-label": "Toggle Menu",
                onClick: onToggleNav,
                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    className: "text-gray-900 dark:text-gray-100",
                    children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                        fillRule: "evenodd",
                        d: "M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z",
                        clipRule: "evenodd"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                className: "fixed top-0 left-0 z-10 h-full w-full transform bg-gray-200 opacity-95 duration-300 ease-in-out dark:bg-gray-800 ".concat(navShow ? "translate-x-0" : "translate-x-full"),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
                            type: "button",
                            className: "mr-5 mt-11 h-8 w-8 rounded",
                            "aria-label": "Toggle Menu",
                            onClick: onToggleNav,
                            children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                className: "text-gray-900 dark:text-gray-100",
                                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                                    fillRule: "evenodd",
                                    d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                    clipRule: "evenodd"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("nav", {
                        className: "fixed mt-8 h-full",
                        children: data_headerNavLinks.map(function(link) {
                            return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                                className: "px-12 py-4",
                                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                                    href: link.href,
                                    className: "text-2xl font-bold tracking-widest text-gray-900 dark:text-gray-100",
                                    onClick: onToggleNav,
                                    children: link.title
                                })
                            }, link.title);
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ var components_MobileNav = (MobileNav);

;// CONCATENATED MODULE: ./components/ThemeSwitch.js



var ThemeSwitch = function() {
    var ref = (0,compat_module.useState)(false), mounted = ref[0], setMounted = ref[1];
    var ref1 = (0,index_modern/* useTheme */.F)(), theme = ref1.theme, setTheme = ref1.setTheme, resolvedTheme = ref1.resolvedTheme;
    // When mounted on client, now we can show the UI
    (0,compat_module.useEffect)(function() {
        return setMounted(true);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("button", {
        "aria-label": "Toggle Dark Mode",
        type: "button",
        className: "ml-1 mr-1 h-8 w-8 rounded p-1 sm:ml-4",
        onClick: function() {
            return setTheme(theme === "dark" || resolvedTheme === "dark" ? "light" : "dark");
        },
        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 20 20",
            fill: "currentColor",
            className: "text-gray-900 dark:text-gray-100",
            children: mounted && (theme === "dark" || resolvedTheme === "dark") ? /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                fillRule: "evenodd",
                d: "M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z",
                clipRule: "evenodd"
            }) : /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("path", {
                d: "M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"
            })
        })
    });
};
/* harmony default export */ var components_ThemeSwitch = (ThemeSwitch);

;// CONCATENATED MODULE: ./components/LayoutWrapper.js









var LayoutWrapper = function(param) {
    var children = param.children;
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(SectionContainer/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
            className: "flex h-screen flex-col justify-between",
            children: [
                /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("header", {
                    className: "flex items-center justify-between py-10",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                            children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                                href: "/",
                                "aria-label": (siteMetadata_default()).headerTitle,
                                children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                                            className: "mr-3",
                                            children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(logo, {})
                                        }),
                                        typeof (siteMetadata_default()).headerTitle === "string" ? /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                                            className: "hidden h-6 text-2xl font-semibold sm:block",
                                            children: (siteMetadata_default()).headerTitle
                                        }) : (siteMetadata_default()).headerTitle
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                            className: "flex items-center text-base leading-5",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                                    className: "hidden sm:block",
                                    children: data_headerNavLinks.map(function(link) {
                                        return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                                            href: link.href,
                                            className: "p-1 font-medium text-gray-900 dark:text-gray-100 sm:p-4",
                                            children: link.title
                                        }, link.title);
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(components_ThemeSwitch, {}),
                                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(components_MobileNav, {})
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("main", {
                    className: "mb-auto",
                    children: children
                }),
                /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Footer, {})
            ]
        })
    });
};
/* harmony default export */ var components_LayoutWrapper = (LayoutWrapper);

// EXTERNAL MODULE: ./node_modules/next/router.js
var router = __webpack_require__(1163);
;// CONCATENATED MODULE: ./components/ClientReload.js


/**
 * Client-side complement to next-remote-watch
 * Re-triggers getStaticProps when watched mdx files change
 *
 */ var ClientReload = function() {
    // Exclude socket.io from prod bundle
    (0,compat_module.useEffect)(function() {
        __webpack_require__.e(/* import() */ 367).then(__webpack_require__.bind(__webpack_require__, 9367)).then(function(module) {
            var socket = module.io();
            socket.on("reload", function(data) {
                router["default"].replace(router["default"].asPath, undefined, {
                    scroll: false
                });
            });
        });
    }, []);
    return null;
};

;// CONCATENATED MODULE: ./pages/_app.js
/* provided dependency */ var process = __webpack_require__(3454);
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}











var isDevelopment = "production" === "development";
var isSocket = process.env.SOCKET;
function App(param) {
    var Component = param.Component, pageProps = param.pageProps;
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(index_modern/* ThemeProvider */.f, {
        attribute: "class",
        defaultTheme: (siteMetadata_default()).theme,
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(head["default"], {
                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                    content: "width=device-width, initial-scale=1",
                    name: "viewport"
                })
            }),
            isDevelopment && isSocket && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(ClientReload, {}),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(analytics, {}),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(components_LayoutWrapper, {
                children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Component, _objectSpread({}, pageProps))
            })
        ]
    });
};


/***/ }),

/***/ 8102:
/***/ (function() {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 3941:
/***/ (function() {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 7661:
/***/ (function() {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 2604:
/***/ (function() {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 7663:
/***/ (function(module) {

var __dirname = "/";
(function(){var e={162:function(e){var t=e.exports={};var r;var n;function defaultSetTimout(){throw new Error("setTimeout has not been defined")}function defaultClearTimeout(){throw new Error("clearTimeout has not been defined")}(function(){try{if(typeof setTimeout==="function"){r=setTimeout}else{r=defaultSetTimout}}catch(e){r=defaultSetTimout}try{if(typeof clearTimeout==="function"){n=clearTimeout}else{n=defaultClearTimeout}}catch(e){n=defaultClearTimeout}})();function runTimeout(e){if(r===setTimeout){return setTimeout(e,0)}if((r===defaultSetTimout||!r)&&setTimeout){r=setTimeout;return setTimeout(e,0)}try{return r(e,0)}catch(t){try{return r.call(null,e,0)}catch(t){return r.call(this,e,0)}}}function runClearTimeout(e){if(n===clearTimeout){return clearTimeout(e)}if((n===defaultClearTimeout||!n)&&clearTimeout){n=clearTimeout;return clearTimeout(e)}try{return n(e)}catch(t){try{return n.call(null,e)}catch(t){return n.call(this,e)}}}var i=[];var o=false;var u;var a=-1;function cleanUpNextTick(){if(!o||!u){return}o=false;if(u.length){i=u.concat(i)}else{a=-1}if(i.length){drainQueue()}}function drainQueue(){if(o){return}var e=runTimeout(cleanUpNextTick);o=true;var t=i.length;while(t){u=i;i=[];while(++a<t){if(u){u[a].run()}}a=-1;t=i.length}u=null;o=false;runClearTimeout(e)}t.nextTick=function(e){var t=new Array(arguments.length-1);if(arguments.length>1){for(var r=1;r<arguments.length;r++){t[r-1]=arguments[r]}}i.push(new Item(e,t));if(i.length===1&&!o){runTimeout(drainQueue)}};function Item(e,t){this.fun=e;this.array=t}Item.prototype.run=function(){this.fun.apply(null,this.array)};t.title="browser";t.browser=true;t.env={};t.argv=[];t.version="";t.versions={};function noop(){}t.on=noop;t.addListener=noop;t.once=noop;t.off=noop;t.removeListener=noop;t.removeAllListeners=noop;t.emit=noop;t.prependListener=noop;t.prependOnceListener=noop;t.listeners=function(e){return[]};t.binding=function(e){throw new Error("process.binding is not supported")};t.cwd=function(){return"/"};t.chdir=function(e){throw new Error("process.chdir is not supported")};t.umask=function(){return 0}}};var t={};function __nccwpck_require__(r){var n=t[r];if(n!==undefined){return n.exports}var i=t[r]={exports:{}};var o=true;try{e[r](i,i.exports,__nccwpck_require__);o=false}finally{if(o)delete t[r]}return i.exports}if(typeof __nccwpck_require__!=="undefined")__nccwpck_require__.ab=__dirname+"/";var r=__nccwpck_require__(162);module.exports=r})();

/***/ }),

/***/ 9008:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(3121)


/***/ }),

/***/ 1664:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(1551)


/***/ }),

/***/ 1163:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(880)


/***/ }),

/***/ 4298:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(3573)


/***/ }),

/***/ 6584:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fragment": function() { return /* reexport safe */ preact__WEBPACK_IMPORTED_MODULE_0__.HY; },
/* harmony export */   "jsx": function() { return /* binding */ e; },
/* harmony export */   "jsxs": function() { return /* binding */ e; },
/* harmony export */   "jsxDEV": function() { return /* binding */ e; }
/* harmony export */ });
/* harmony import */ var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6400);
var o=0;function e(_,e,n,t,f){var l,s,u={};for(s in e)"ref"==s?l=e[s]:u[s]=e[s];var a={type:_,props:u,key:n,ref:l,__k:null,__:null,__b:0,__e:null,__d:void 0,__c:null,__h:null,constructor:void 0,__v:--o,__source:t,__self:f};if("function"==typeof _&&(l=_.defaultProps))for(s in l)void 0===u[s]&&(u[s]=l[s]);return preact__WEBPACK_IMPORTED_MODULE_0__/* .options.vnode */ .YM.vnode&&preact__WEBPACK_IMPORTED_MODULE_0__/* .options.vnode */ .YM.vnode(a),a}
//# sourceMappingURL=jsxRuntime.module.js.map


/***/ }),

/***/ 7320:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HY": function() { return /* reexport safe */ preact_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment; },
/* harmony export */   "tZ": function() { return /* reexport safe */ preact_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx; },
/* harmony export */   "BX": function() { return /* reexport safe */ preact_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs; }
/* harmony export */ });
/* harmony import */ var preact_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6584);



/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [179], function() { return __webpack_exec__(1780), __webpack_exec__(880); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=_app-bb08c6eb57740604.js.map