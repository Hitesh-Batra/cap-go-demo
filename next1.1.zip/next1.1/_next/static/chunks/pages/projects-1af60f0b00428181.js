(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[327],{

/***/ 8947:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/projects",
      function () {
        return __webpack_require__(2806);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 8100:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _extends() {
    _extends = Object.assign || function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}


// eslint-disable-next-line jsx-a11y/alt-text
var Image = function(_param) /*#__PURE__*/ {
    var rest = _extends({}, _param);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], _objectSpread({}, rest));
};
/* harmony default export */ __webpack_exports__["Z"] = (Image);


/***/ }),

/***/ 9831:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TQ": function() { return /* binding */ PageSEO; },
/* harmony export */   "$t": function() { return /* binding */ TagSEO; },
/* harmony export */   "Uy": function() { return /* binding */ BlogSEO; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9008);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1163);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);




var CommonSEO = function(param1) {
    var title = param1.title, description = param1.description, ogType = param1.ogType, ogImage = param1.ogImage, twImage = param1.twImage, canonicalUrl = param1.canonicalUrl;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("title", {
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "robots",
                content: "follow, index"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:url",
                content: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:type",
                content: ogType
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:site_name",
                content: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().title)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:title",
                content: title
            }),
            ogImage.constructor.name === "Array" ? ogImage.map(function(param) {
                var url = param.url;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                    property: "og:image",
                    content: url
                }, url);
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                property: "og:image",
                content: ogImage
            }, ogImage),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:site",
                content: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().twitter)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:title",
                content: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                name: "twitter:image",
                content: twImage
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("link", {
                rel: "canonical",
                href: canonicalUrl ? canonicalUrl : "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath)
            })
        ]
    });
};
var PageSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var twImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
        title: title,
        description: description,
        ogType: "website",
        ogImage: ogImageUrl,
        twImage: twImageUrl
    });
};
var TagSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var twImageUrl = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner);
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
                title: title,
                description: description,
                ogType: "website",
                ogImage: ogImageUrl,
                twImage: twImageUrl
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("link", {
                    rel: "alternate",
                    type: "application/rss+xml",
                    title: "".concat(description, " - RSS feed"),
                    href: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat(router.asPath, "/feed.xml")
                })
            })
        ]
    });
};
var BlogSEO = function(param) {
    var authorDetails = param.authorDetails, title = param.title, summary = param.summary, date = param.date, lastmod = param.lastmod, url = param.url, _images = param.images, images = _images === void 0 ? [] : _images, canonicalUrl = param.canonicalUrl;
    var router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    var publishedAt = new Date(date).toISOString();
    var modifiedAt = new Date(lastmod || date).toISOString();
    var imagesArr = images.length === 0 ? [
        (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().socialBanner)
    ] : typeof images === "string" ? [
        images
    ] : images;
    var featuredImages = imagesArr.map(function(img) {
        return {
            "@type": "ImageObject",
            url: img.includes("http") ? img : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl) + img
        };
    });
    var authorList;
    if (authorDetails) {
        authorList = authorDetails.map(function(author) {
            return {
                "@type": "Person",
                name: author.name
            };
        });
    } else {
        authorList = {
            "@type": "Person",
            name: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().author)
        };
    }
    var structuredData = {
        "@context": "https://schema.org",
        "@type": "Article",
        mainEntityOfPage: {
            "@type": "WebPage",
            "@id": url
        },
        headline: title,
        image: featuredImages,
        datePublished: publishedAt,
        dateModified: modifiedAt,
        author: authorList,
        publisher: {
            "@type": "Organization",
            name: (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().author),
            logo: {
                "@type": "ImageObject",
                url: "".concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteUrl)).concat((_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().siteLogo))
            }
        },
        description: summary
    };
    var twImageUrl = featuredImages[0].url;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .Fragment */ .HY, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(CommonSEO, {
                title: title,
                description: summary,
                ogType: "article",
                ogImage: featuredImages,
                twImage: twImageUrl,
                canonicalUrl: canonicalUrl
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)(next_head__WEBPACK_IMPORTED_MODULE_1__["default"], {
                children: [
                    date && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                        property: "article:published_time",
                        content: publishedAt
                    }),
                    lastmod && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("meta", {
                        property: "article:modified_time",
                        content: modifiedAt
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(structuredData, null, 2)
                        }
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 2806:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Projects; }
});

// EXTERNAL MODULE: ./node_modules/preact/compat/jsx-runtime.mjs
var jsx_runtime = __webpack_require__(7320);
// EXTERNAL MODULE: ./data/siteMetadata.js
var siteMetadata = __webpack_require__(1576);
var siteMetadata_default = /*#__PURE__*/__webpack_require__.n(siteMetadata);
;// CONCATENATED MODULE: ./data/projectsData.js
var projectsData = [
    {
        title: "A Search Engine",
        description: "What if you could look up any information in the world? Webpages, images, videos\n    and more. Google has many features to help you find exactly what you're looking\n    for.",
        imgSrc: "/static/images/google.png",
        href: "https://www.google.com"
    },
    {
        title: "The Time Machine",
        description: 'Imagine being able to travel back in time or to the future. Simple turn the knob\n    to the desired date and press "Go". No more worrying about lost keys or\n    forgotten headphones with this simple yet affordable solution.',
        imgSrc: "/static/images/time-machine.jpg",
        href: "/blog/the-time-machine"
    }, 
];
/* harmony default export */ var data_projectsData = (projectsData);

// EXTERNAL MODULE: ./components/Image.js
var Image = __webpack_require__(8100);
// EXTERNAL MODULE: ./components/Link.js
var Link = __webpack_require__(7233);
;// CONCATENATED MODULE: ./components/Card.js



var Card = function(param) {
    var title = param.title, description = param.description, imgSrc = param.imgSrc, href = param.href;
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
        className: "md p-4 md:w-1/2",
        style: {
            maxWidth: "544px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
            className: "".concat(imgSrc && "h-full", "  overflow-hidden rounded-md border-2 border-gray-200 border-opacity-60 dark:border-gray-700"),
            children: [
                imgSrc && (href ? /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                    href: href,
                    "aria-label": "Link to ".concat(title),
                    children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Image/* default */.Z, {
                        alt: title,
                        src: imgSrc,
                        className: "object-cover object-center md:h-36 lg:h-48",
                        width: 544,
                        height: 306
                    })
                }) : /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Image/* default */.Z, {
                    alt: title,
                    src: imgSrc,
                    className: "object-cover object-center md:h-36 lg:h-48",
                    width: 544,
                    height: 306
                })),
                /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                    className: "p-6",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("h2", {
                            className: "mb-3 text-2xl font-bold leading-8 tracking-tight",
                            children: href ? /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                                href: href,
                                "aria-label": "Link to ".concat(title),
                                children: title
                            }) : title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("p", {
                            className: "prose mb-3 max-w-none text-gray-500 dark:text-gray-400",
                            children: description
                        }),
                        href && /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(Link/* default */.Z, {
                            href: href,
                            className: "text-base font-medium leading-6 text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
                            "aria-label": "Link to ".concat(title),
                            children: "Learn more \u2192"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ var components_Card = (Card);

// EXTERNAL MODULE: ./components/SEO.js
var SEO = __webpack_require__(9831);
;// CONCATENATED MODULE: ./pages/projects.js





function Projects() {
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(SEO/* PageSEO */.TQ, {
                title: "Projects - ".concat((siteMetadata_default()).author),
                description: (siteMetadata_default()).description
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                className: "divide-y divide-gray-200 dark:divide-gray-700",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                        className: "space-y-2 pt-6 pb-8 md:space-y-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("h1", {
                                className: "text-3xl font-extrabold leading-9 tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl sm:leading-10 md:text-6xl md:leading-14",
                                children: "Projects"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("p", {
                                className: "text-lg leading-7 text-gray-500 dark:text-gray-400",
                                children: "Showcase your projects with a hero image (16 x 9)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                        className: "container py-12",
                        children: /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                            className: "-m-4 flex flex-wrap",
                            children: data_projectsData.map(function(d) {
                                return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(components_Card, {
                                    title: d.title,
                                    description: d.description,
                                    imgSrc: d.imgSrc,
                                    href: d.href
                                }, d.title);
                            })
                        })
                    })
                ]
            })
        ]
    });
};


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [675,888,179], function() { return __webpack_exec__(8947); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=projects-1af60f0b00428181.js.map