(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[521],{

/***/ 8961:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/about",
      function () {
        return __webpack_require__(8953);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 8953:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSG": function() { return /* binding */ __N_SSG; },
/* harmony export */   "default": function() { return /* binding */ About; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var _components_MDXComponents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1712);


var DEFAULT_LAYOUT = "AuthorLayout";
var __N_SSG = true;
function About(param) {
    var authorDetails = param.authorDetails;
    var mdxSource = authorDetails.mdxSource, frontMatter = authorDetails.frontMatter;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)(_components_MDXComponents__WEBPACK_IMPORTED_MODULE_1__/* .MDXLayoutRenderer */ .J, {
        layout: frontMatter.layout || DEFAULT_LAYOUT,
        mdxSource: mdxSource,
        frontMatter: frontMatter
    });
};


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [675,410,712,888,179], function() { return __webpack_exec__(8961); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=about-25c1307fc4601cd5.js.map