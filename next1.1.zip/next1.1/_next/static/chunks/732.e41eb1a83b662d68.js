"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[732],{

/***/ 732:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7320);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1720);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(425);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1576);
/* harmony import */ var _data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3__);




var Giscus = function() {
    var ref3 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true), enableLoadComments = ref3[0], setEnabledLoadComments = ref3[1];
    var ref1 = (0,next_themes__WEBPACK_IMPORTED_MODULE_2__/* .useTheme */ .F)(), theme = ref1.theme, resolvedTheme = ref1.resolvedTheme;
    var commentsTheme = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.giscusConfig.themeURL) === "" ? theme === "dark" || resolvedTheme === "dark" ? (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.giscusConfig.darkTheme) : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.giscusConfig.theme) : (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment.giscusConfig.themeURL);
    var COMMENTS_ID = "comments-container";
    var LoadComments = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function() {
        var ref;
        setEnabledLoadComments(false);
        var ref2 = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default()) === null || (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default()) === void 0 ? void 0 : (ref = (_data_siteMetadata__WEBPACK_IMPORTED_MODULE_3___default().comment)) === null || ref === void 0 ? void 0 : ref.giscusConfig, repo = ref2.repo, repositoryId = ref2.repositoryId, category = ref2.category, categoryId = ref2.categoryId, mapping = ref2.mapping, reactions = ref2.reactions, metadata = ref2.metadata, inputPosition = ref2.inputPosition, lang = ref2.lang;
        var script = document.createElement("script");
        script.src = "https://giscus.app/client.js";
        script.setAttribute("data-repo", repo);
        script.setAttribute("data-repo-id", repositoryId);
        script.setAttribute("data-category", category);
        script.setAttribute("data-category-id", categoryId);
        script.setAttribute("data-mapping", mapping);
        script.setAttribute("data-reactions-enabled", reactions);
        script.setAttribute("data-emit-metadata", metadata);
        script.setAttribute("data-input-position", inputPosition);
        script.setAttribute("data-lang", lang);
        script.setAttribute("data-theme", commentsTheme);
        script.setAttribute("crossorigin", "anonymous");
        script.async = true;
        var comments1 = document.getElementById(COMMENTS_ID);
        if (comments1) comments1.appendChild(script);
        return function() {
            var comments = document.getElementById(COMMENTS_ID);
            if (comments) comments.innerHTML = "";
        };
    }, [
        commentsTheme
    ]);
    // Reload on theme change
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function() {
        var iframe = document.querySelector("iframe.giscus-frame");
        if (!iframe) return;
        LoadComments();
    }, [
        LoadComments
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsxs */ .BX)("div", {
        className: "pt-6 pb-6 text-center text-gray-700 dark:text-gray-300",
        children: [
            enableLoadComments && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("button", {
                onClick: LoadComments,
                children: "Load Comments"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__/* .jsx */ .tZ)("div", {
                className: "giscus",
                id: COMMENTS_ID
            })
        ]
    });
};
/* harmony default export */ __webpack_exports__["default"] = (Giscus);


/***/ })

}]);
//# sourceMappingURL=732.e41eb1a83b662d68.js.map