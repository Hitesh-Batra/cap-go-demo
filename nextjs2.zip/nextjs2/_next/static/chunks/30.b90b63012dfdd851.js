"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[30],{

/***/ 3030:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashScreenWeb": function() { return /* binding */ SplashScreenWeb; }
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9895);

class SplashScreenWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_0__/* .WebPlugin */ .Uw {
    async show(_options) {
        return undefined;
    }
    async hide(_options) {
        return undefined;
    }
}
//# sourceMappingURL=web.js.map

/***/ })

}]);
//# sourceMappingURL=30.b90b63012dfdd851.js.map