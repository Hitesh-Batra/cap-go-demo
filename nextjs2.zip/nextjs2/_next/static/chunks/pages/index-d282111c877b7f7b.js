(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[405],{

/***/ 8581:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/",
      function () {
        return __webpack_require__(5340);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 1576:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/* provided dependency */ var process = __webpack_require__(3454);

var siteMetadata = {
    title: "Next.js Starter Blog",
    author: "Tails Azimuth",
    headerTitle: "TailwindBlog",
    description: "A blog created with Next.js and Tailwind.css",
    language: "en-us",
    theme: "system",
    siteUrl: "https://tailwind-nextjs-starter-blog.vercel.app",
    siteRepo: "https://github.com/timlrx/tailwind-nextjs-starter-blog",
    siteLogo: "/static/images/logo.png",
    image: "/static/images/avatar.png",
    socialBanner: "/static/images/twitter-card.png",
    email: "address@yoursite.com",
    github: "https://github.com",
    twitter: "https://twitter.com/Twitter",
    facebook: "https://facebook.com",
    youtube: "https://youtube.com",
    linkedin: "https://www.linkedin.com",
    locale: "en-US",
    analytics: {
        // If you want to use an analytics provider you have to add it to the
        // content security policy in the `next.config.js` file.
        // supports plausible, simpleAnalytics, umami or googleAnalytics
        plausibleDataDomain: "",
        simpleAnalytics: false,
        umamiWebsiteId: "",
        googleAnalyticsId: "",
        posthogAnalyticsId: ""
    },
    newsletter: {
        // supports mailchimp, buttondown, convertkit, klaviyo, revue, emailoctopus
        // Please add your .env file and modify it according to your selection
        provider: "buttondown"
    },
    comment: {
        // If you want to use a commenting system other than giscus you have to add it to the
        // content security policy in the `next.config.js` file.
        // Select a provider and use the environment variables associated to it
        // https://vercel.com/docs/environment-variables
        provider: "giscus",
        giscusConfig: {
            // Visit the link below, and follow the steps in the 'configuration' section
            // https://giscus.app/
            repo: process.env.NEXT_PUBLIC_GISCUS_REPO,
            repositoryId: process.env.NEXT_PUBLIC_GISCUS_REPOSITORY_ID,
            category: process.env.NEXT_PUBLIC_GISCUS_CATEGORY,
            categoryId: process.env.NEXT_PUBLIC_GISCUS_CATEGORY_ID,
            mapping: "pathname",
            reactions: "1",
            // Send discussion metadata periodically to the parent window: 1 = enable / 0 = disable
            metadata: "0",
            // theme example: light, dark, dark_dimmed, dark_high_contrast
            // transparent_dark, preferred_color_scheme, custom
            theme: "light",
            // Place the comment box above the comments. options: bottom, top
            inputPosition: "bottom",
            // Choose the language giscus will be displayed in. options: en, es, zh-CN, zh-TW, ko, ja etc
            lang: "en",
            // theme when dark mode
            darkTheme: "transparent_dark",
            // If the theme option above is set to 'custom`
            // please provide a link below to your custom theme css file.
            // example: https://giscus.app/themes/custom_example.css
            themeURL: ""
        },
        utterancesConfig: {
            // Visit the link below, and follow the steps in the 'configuration' section
            // https://utteranc.es/
            repo: process.env.NEXT_PUBLIC_UTTERANCES_REPO,
            issueTerm: "",
            label: "",
            // theme example: github-light, github-dark, preferred-color-scheme
            // github-dark-orange, icy-dark, dark-blue, photon-dark, boxy-light
            theme: "",
            // theme when dark mode
            darkTheme: ""
        },
        disqusConfig: {
            // https://help.disqus.com/en/articles/1717111-what-s-a-shortname
            shortname: process.env.NEXT_PUBLIC_DISQUS_SHORTNAME
        }
    }
};
module.exports = siteMetadata;


/***/ }),

/***/ 5340:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "__N_SSG": function() { return /* binding */ __N_SSG; },
  "default": function() { return /* binding */ Home; }
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/regenerator-runtime/runtime.js
var runtime = __webpack_require__(4051);
var runtime_default = /*#__PURE__*/__webpack_require__.n(runtime);
// EXTERNAL MODULE: ./node_modules/preact/compat/jsx-runtime.mjs + 1 modules
var jsx_runtime = __webpack_require__(7997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Link.js
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}

/* eslint-disable jsx-a11y/anchor-has-content */ 
var CustomLink = function(_param) {
    var href = _param.href, rest = _objectWithoutProperties(_param, [
        "href"
    ]);
    var isInternalLink = href && href.startsWith("/");
    var isAnchorLink = href && href.startsWith("#");
    if (isInternalLink) {
        return /*#__PURE__*/ _jsx(Link, {
            href: href,
            children: /*#__PURE__*/ _jsx("a", _objectSpread({}, rest))
        });
    }
    if (isAnchorLink) {
        return /*#__PURE__*/ _jsx("a", _objectSpread({
            href: href
        }, rest));
    }
    return /*#__PURE__*/ _jsx("a", _objectSpread({
        target: "_blank",
        rel: "noopener noreferrer",
        href: href
    }, rest));
};
/* harmony default export */ var components_Link = ((/* unused pure expression or super */ null && (CustomLink)));

// EXTERNAL MODULE: ./node_modules/next/head.js
var head = __webpack_require__(9008);
// EXTERNAL MODULE: ./node_modules/next/router.js
var next_router = __webpack_require__(1163);
// EXTERNAL MODULE: ./data/siteMetadata.js
var data_siteMetadata = __webpack_require__(1576);
var siteMetadata_default = /*#__PURE__*/__webpack_require__.n(data_siteMetadata);
;// CONCATENATED MODULE: ./components/SEO.js




var CommonSEO = function(param1) {
    var title = param1.title, description = param1.description, ogType = param1.ogType, ogImage = param1.ogImage, twImage = param1.twImage, canonicalUrl = param1.canonicalUrl;
    var router = (0,next_router.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(head["default"], {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("title", {
                children: title
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "robots",
                content: "follow, index"
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "description",
                content: description
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                property: "og:url",
                content: "".concat((siteMetadata_default()).siteUrl).concat(router.asPath)
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                property: "og:type",
                content: ogType
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                property: "og:site_name",
                content: (siteMetadata_default()).title
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                property: "og:description",
                content: description
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                property: "og:title",
                content: title
            }),
            ogImage.constructor.name === "Array" ? ogImage.map(function(param) {
                var url = param.url;
                return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                    property: "og:image",
                    content: url
                }, url);
            }) : /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                property: "og:image",
                content: ogImage
            }, ogImage),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "twitter:site",
                content: (siteMetadata_default()).twitter
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "twitter:title",
                content: title
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "twitter:description",
                content: description
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("meta", {
                name: "twitter:image",
                content: twImage
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("link", {
                rel: "canonical",
                href: canonicalUrl ? canonicalUrl : "".concat((siteMetadata_default()).siteUrl).concat(router.asPath)
            })
        ]
    });
};
var PageSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = (siteMetadata_default()).siteUrl + (siteMetadata_default()).socialBanner;
    var twImageUrl = (siteMetadata_default()).siteUrl + (siteMetadata_default()).socialBanner;
    return /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(CommonSEO, {
        title: title,
        description: description,
        ogType: "website",
        ogImage: ogImageUrl,
        twImage: twImageUrl
    });
};
var TagSEO = function(param) {
    var title = param.title, description = param.description;
    var ogImageUrl = siteMetadata.siteUrl + siteMetadata.socialBanner;
    var twImageUrl = siteMetadata.siteUrl + siteMetadata.socialBanner;
    var router = useRouter();
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(CommonSEO, {
                title: title,
                description: description,
                ogType: "website",
                ogImage: ogImageUrl,
                twImage: twImageUrl
            }),
            /*#__PURE__*/ _jsx(Head, {
                children: /*#__PURE__*/ _jsx("link", {
                    rel: "alternate",
                    type: "application/rss+xml",
                    title: "".concat(description, " - RSS feed"),
                    href: "".concat(siteMetadata.siteUrl).concat(router.asPath, "/feed.xml")
                })
            })
        ]
    });
};
var BlogSEO = function(param) {
    var authorDetails = param.authorDetails, title = param.title, summary = param.summary, date = param.date, lastmod = param.lastmod, url = param.url, _images = param.images, images = _images === void 0 ? [] : _images, canonicalUrl = param.canonicalUrl;
    var router = useRouter();
    var publishedAt = new Date(date).toISOString();
    var modifiedAt = new Date(lastmod || date).toISOString();
    var imagesArr = images.length === 0 ? [
        siteMetadata.socialBanner
    ] : typeof images === "string" ? [
        images
    ] : images;
    var featuredImages = imagesArr.map(function(img) {
        return {
            "@type": "ImageObject",
            url: img.includes("http") ? img : siteMetadata.siteUrl + img
        };
    });
    var authorList;
    if (authorDetails) {
        authorList = authorDetails.map(function(author) {
            return {
                "@type": "Person",
                name: author.name
            };
        });
    } else {
        authorList = {
            "@type": "Person",
            name: siteMetadata.author
        };
    }
    var structuredData = {
        "@context": "https://schema.org",
        "@type": "Article",
        mainEntityOfPage: {
            "@type": "WebPage",
            "@id": url
        },
        headline: title,
        image: featuredImages,
        datePublished: publishedAt,
        dateModified: modifiedAt,
        author: authorList,
        publisher: {
            "@type": "Organization",
            name: siteMetadata.author,
            logo: {
                "@type": "ImageObject",
                url: "".concat(siteMetadata.siteUrl).concat(siteMetadata.siteLogo)
            }
        },
        description: summary
    };
    var twImageUrl = featuredImages[0].url;
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(CommonSEO, {
                title: title,
                description: summary,
                ogType: "article",
                ogImage: featuredImages,
                twImage: twImageUrl,
                canonicalUrl: canonicalUrl
            }),
            /*#__PURE__*/ _jsxs(Head, {
                children: [
                    date && /*#__PURE__*/ _jsx("meta", {
                        property: "article:published_time",
                        content: publishedAt
                    }),
                    lastmod && /*#__PURE__*/ _jsx("meta", {
                        property: "article:modified_time",
                        content: modifiedAt
                    }),
                    /*#__PURE__*/ _jsx("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(structuredData, null, 2)
                        }
                    })
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/github-slugger/index.js
var github_slugger = __webpack_require__(9671);
;// CONCATENATED MODULE: ./lib/utils/kebabCase.js

var kebabCase_kebabCase = function(str) {
    return slug(str);
};
/* harmony default export */ var utils_kebabCase = ((/* unused pure expression or super */ null && (kebabCase_kebabCase)));

;// CONCATENATED MODULE: ./components/Tag.js



var Tag = function(param) {
    var text = param.text;
    return /*#__PURE__*/ _jsx(Link, {
        href: "/tags/".concat(kebabCase(text)),
        children: /*#__PURE__*/ _jsx("a", {
            className: "mr-3 text-sm font-medium uppercase text-primary-500 hover:text-primary-600 dark:hover:text-primary-400",
            children: text.split(" ").join("-")
        })
    });
};
/* harmony default export */ var components_Tag = ((/* unused pure expression or super */ null && (Tag)));

;// CONCATENATED MODULE: ./lib/utils/formatDate.js

var formatDate = function(date) {
    var options = {
        year: "numeric",
        month: "long",
        day: "numeric"
    };
    var now = new Date(date).toLocaleDateString(siteMetadata.locale, options);
    return now;
};
/* harmony default export */ var utils_formatDate = ((/* unused pure expression or super */ null && (formatDate)));

// EXTERNAL MODULE: ./node_modules/preact/compat/dist/compat.module.js + 1 modules
var compat_module = __webpack_require__(1720);
;// CONCATENATED MODULE: ./components/NewsletterForm.js
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}




var NewsletterForm = function(param) {
    var _title = param.title, title = _title === void 0 ? "Subscribe to the newsletter" : _title;
    var inputEl = useRef(null);
    var ref = useState(false), error1 = ref[0], setError = ref[1];
    var ref1 = useState(""), message = ref1[0], setMessage = ref1[1];
    var ref2 = useState(false), subscribed = ref2[0], setSubscribed = ref2[1];
    var subscribe = function() {
        var _ref = _asyncToGenerator(regeneratorRuntime.mark(function _callee(e) {
            var res, error;
            return regeneratorRuntime.wrap(function _callee$(_ctx) {
                while(1)switch(_ctx.prev = _ctx.next){
                    case 0:
                        e.preventDefault();
                        _ctx.next = 3;
                        return fetch("/api/".concat(siteMetadata.newsletter.provider), {
                            body: JSON.stringify({
                                email: inputEl.current.value
                            }),
                            headers: {
                                "Content-Type": "application/json"
                            },
                            method: "POST"
                        });
                    case 3:
                        res = _ctx.sent;
                        _ctx.next = 6;
                        return res.json();
                    case 6:
                        error = _ctx.sent.error;
                        if (!error) {
                            _ctx.next = 11;
                            break;
                        }
                        setError(true);
                        setMessage("Your e-mail address is invalid or you are already subscribed!");
                        return _ctx.abrupt("return");
                    case 11:
                        inputEl.current.value = "";
                        setError(false);
                        setSubscribed(true);
                        setMessage("Successfully! \uD83C\uDF89 You are now subscribed.");
                    case 15:
                    case "end":
                        return _ctx.stop();
                }
            }, _callee);
        }));
        return function subscribe(e) {
            return _ref.apply(this, arguments);
        };
    }();
    return /*#__PURE__*/ _jsxs("div", {
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "pb-1 text-lg font-semibold text-gray-800 dark:text-gray-100",
                children: title
            }),
            /*#__PURE__*/ _jsxs("form", {
                className: "flex flex-col sm:flex-row",
                onSubmit: subscribe,
                children: [
                    /*#__PURE__*/ _jsxs("div", {
                        children: [
                            /*#__PURE__*/ _jsx("label", {
                                className: "sr-only",
                                htmlFor: "email-input",
                                children: "Email address"
                            }),
                            /*#__PURE__*/ _jsx("input", {
                                autoComplete: "email",
                                className: "w-72 rounded-md px-4 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-primary-600 dark:bg-black",
                                id: "email-input",
                                name: "email",
                                placeholder: subscribed ? "You're subscribed !  \uD83C\uDF89" : "Enter your email",
                                ref: inputEl,
                                required: true,
                                type: "email",
                                disabled: subscribed
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "mt-2 flex w-full rounded-md shadow-sm sm:mt-0 sm:ml-3",
                        children: /*#__PURE__*/ _jsx("button", {
                            className: "w-full rounded-md bg-primary-500 py-2 px-4 font-medium text-white sm:py-0 ".concat(subscribed ? "cursor-default" : "hover:bg-primary-700 dark:hover:bg-primary-400", " focus:outline-none focus:ring-2 focus:ring-primary-600 focus:ring-offset-2 dark:ring-offset-black"),
                            type: "submit",
                            disabled: subscribed,
                            children: subscribed ? "Thank you!" : "Sign up"
                        })
                    })
                ]
            }),
            error1 && /*#__PURE__*/ _jsx("div", {
                className: "w-72 pt-2 text-sm text-red-500 dark:text-red-400 sm:w-96",
                children: message
            })
        ]
    });
};
/* harmony default export */ var components_NewsletterForm = ((/* unused pure expression or super */ null && (NewsletterForm)));
var BlogNewsletterForm = function(param) {
    var title = param.title;
    return /*#__PURE__*/ _jsx("div", {
        className: "flex items-center justify-center",
        children: /*#__PURE__*/ _jsx("div", {
            className: "bg-gray-100 p-6 dark:bg-gray-800 sm:px-14 sm:py-8",
            children: /*#__PURE__*/ _jsx(NewsletterForm, {
                title: title
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@capgo/capacitor-updater/dist/esm/index.js
var esm = __webpack_require__(5767);
// EXTERNAL MODULE: ./node_modules/@capacitor/splash-screen/dist/esm/index.js
var dist_esm = __webpack_require__(125);
// EXTERNAL MODULE: ./node_modules/@capacitor/app/dist/esm/index.js
var app_dist_esm = __webpack_require__(5137);
;// CONCATENATED MODULE: ./pages/index.js
function pages_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function pages_asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                pages_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                pages_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}


/* eslint-disable no-undef */ 






//import type { BundleInfo } from '@capgo/capacitor-updater'


var data = {
    version: ""
};
esm/* CapacitorUpdater.notifyAppReady */.O.notifyAppReady();
app_dist_esm/* App.addListener */.g.addListener("appStateChange", function() {
    var _ref = pages_asyncToGenerator(runtime_default().mark(function _callee(state) {
        var response, a, i;
        return runtime_default().wrap(function _callee$(_ctx) {
            while(1)switch(_ctx.prev = _ctx.next){
                case 0:
                    if (!state.isActive) {
                        _ctx.next = 23;
                        break;
                    }
                    _ctx.next = 3;
                    return fetch("https://mocki.io/v1/447e9b5a-7e09-4e65-a05a-d03e2a0624b4");
                case 3:
                    response = _ctx.sent;
                    console.log("response data", response);
                    a = 0;
                    i = 2 + a++;
                    console.log("i", i);
                    if (!(i == 1)) {
                        _ctx.next = 15;
                        break;
                    }
                    console.log("i in 1", i);
                    _ctx.next = 12;
                    return esm/* CapacitorUpdater.download */.O.download({
                        url: "https://github.com/Hitesh-Batra/cap-go-demo/raw/main/nextjs.zip",
                        version: "0.0.3"
                    });
                case 12:
                    data = _ctx.sent;
                    _ctx.next = 23;
                    break;
                case 15:
                    if (!(i == 2)) {
                        _ctx.next = 22;
                        break;
                    }
                    console.log("i in 2", i);
                    _ctx.next = 19;
                    return esm/* CapacitorUpdater.download */.O.download({
                        url: "https://github.com/Hitesh-Batra/cap-go-demo/raw/main/next1.1.zip",
                        version: "0.0.4"
                    });
                case 19:
                    data = _ctx.sent;
                    _ctx.next = 23;
                    break;
                case 22:
                    {
                        console.log("Reset your App");
                    }
                case 23:
                    console.log("data---->", data);
                    _ctx.t0 = console;
                    _ctx.next = 27;
                    return esm/* CapacitorUpdater.current */.O.current();
                case 27:
                    _ctx.t1 = _ctx.sent;
                    _ctx.t0.log.call(_ctx.t0, "current version ---->", _ctx.t1);
                    if (!(!state.isActive && data.version !== "")) {
                        _ctx.next = 46;
                        break;
                    }
                    console.log("App is background");
                    _ctx.t2 = console;
                    _ctx.next = 34;
                    return esm/* CapacitorUpdater.list */.O.list();
                case 34:
                    _ctx.t3 = _ctx.sent;
                    _ctx.t2.log.call(_ctx.t2, "bundle list", _ctx.t3);
                    // Activate the update when the application is sent to background
                    dist_esm/* SplashScreen.show */.c.show();
                    _ctx.prev = 37;
                    _ctx.next = 40;
                    return esm/* CapacitorUpdater.set */.O.set(data);
                case 40:
                    _ctx.next = 46;
                    break;
                case 42:
                    _ctx.prev = 42;
                    _ctx.t4 = _ctx["catch"](37);
                    console.log("exceptionVar", _ctx.t4);
                    dist_esm/* SplashScreen.hide */.c.hide() // Hide the splash screen again if something went wrong
                    ;
                case 46:
                case "end":
                    return _ctx.stop();
            }
        }, _callee, null, [
            [
                37,
                42
            ]
        ]);
    }));
    return function(state) {
        return _ref.apply(this, arguments);
    };
}());
esm/* CapacitorUpdater.addListener */.O.addListener("downloadComplete", function(info) {
    console.log("downloadComplete", info);
});
esm/* CapacitorUpdater.addListener */.O.addListener("updateFailed", function(info) {
    console.log("updateFailed", info);
});
esm/* CapacitorUpdater.addListener */.O.addListener("downloadFailed", function(info) {
    console.log("downloadFailed", info);
});
// let data: BundleInfo | null = null
// App.addListener('appStateChange', async (state) => {
//   console.log('appStateChange', state)
//   if (state.isActive) {
//     console.log('getLatest')
//     // Do the download during user active app time to prevent failed download
//     const latest = await CapacitorUpdater.getLatest()
//     console.log('latest', latest)
//     if (latest.url) {
//       data = await CapacitorUpdater.download({
//         url: latest.url,
//         version: latest.version,
//       })
//       // eslint-disable-next-line no-undef
//       console.log('download', data)
//     }
//   }
//   if (!state.isActive) {
//     console.log('set')
//     // Do the switch when user leave app or when you want
//     SplashScreen.show()
//     try {
//       //await CapacitorUpdater.set({ id: data.id })
//     } catch (err) {
//       console.log(err)
//       SplashScreen.hide() // in case the set fail, otherwise the new app will have to hide it
//     }
//   }
// })
esm/* CapacitorUpdater.addListener */.O.addListener("majorAvailable", function(info) {
    console.log("majorAvailable was fired", info.version);
});
var MAX_DISPLAY = 5;
var __N_SSG = true;
function Home(param) {
    var posts = param.posts;
    return /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)(jsx_runtime/* Fragment */.HY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)(PageSEO, {
                title: (siteMetadata_default()).title,
                description: (siteMetadata_default()).description
            }),
            /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("div", {
                className: "divide-y divide-gray-200 dark:divide-gray-700",
                children: /*#__PURE__*/ (0,jsx_runtime/* jsxs */.BX)("div", {
                    className: "space-y-2 pt-6 pb-8 md:space-y-5",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("h1", {
                            className: "text-3xl font-extrabold leading-9 tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl sm:leading-10 md:text-6xl md:leading-14",
                            children: "Check Capgo with the new frontend"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime/* jsx */.tZ)("p", {
                            className: "text-lg leading-7 text-gray-500 dark:text-gray-400",
                            children: (siteMetadata_default()).description
                        })
                    ]
                })
            })
        ]
    });
};


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [343,888,179], function() { return __webpack_exec__(8581); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
//# sourceMappingURL=index-d282111c877b7f7b.js.map